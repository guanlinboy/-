﻿import tkinter as tk
from tkinter import ttk, filedialog, messagebox, simpledialog
import pandas as pd
import numpy as np
import re
from typing import Optional, List, Dict, Any


class ExcelSearchModule:
    """Excel工具功能模块 - 增强版"""
    
    def __init__(self, notebook, status_bar):
        self.notebook = notebook
        self.status_bar = status_bar
        
        self.tab_frame = ttk.Frame(notebook)
        notebook.add(self.tab_frame, text="Excel工具")
        
        self.setup_ui()
        self.current_file = None
        self.current_df = None
        self.current_sheet_name = None
        self.search_results = None
        self.original_df = None  # 保存原始数据用于撤销
        self.history_stack = []  # 操作历史栈
        
    def setup_ui(self):
        """设置用户界面"""
        main_frame = ttk.Frame(self.tab_frame, padding="10")
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        # 文件选择区域
        file_frame = ttk.LabelFrame(main_frame, text="文件选择", padding="5")
        file_frame.pack(fill=tk.X, pady=(0, 10))
        
        self.file_var = tk.StringVar()
        file_entry = ttk.Entry(file_frame, textvariable=self.file_var, width=50)
        file_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 5))
        
        ttk.Button(file_frame, text="浏览", command=self.browse_file).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Button(file_frame, text="刷新", command=self.reload_file).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Button(file_frame, text="切换Sheet", command=self.switch_sheet).pack(side=tk.RIGHT)
        
        # 功能标签页
        self.function_notebook = ttk.Notebook(main_frame)
        self.function_notebook.pack(fill=tk.BOTH, expand=True, pady=(0, 10))
        
        self.setup_search_tab()
        self.setup_calculation_tab()
        self.setup_analysis_tab()
        self.setup_filter_tab()       # 新增：筛选功能
        self.setup_transform_tab()    # 新增：转换功能
        self.setup_merge_tab()        # 新增：合并功能
        self.setup_visualization_tab()  # 新增：数据可视化功能
        
        # 结果显示区域
        results_frame = ttk.LabelFrame(main_frame, text="结果", padding="5")
        results_frame.pack(fill=tk.BOTH, expand=True)
        
        columns = ("行", "列", "内容", "附加信息")
        self.results_tree = ttk.Treeview(results_frame, columns=columns, show="headings", height=12)
        
        for col in columns:
            self.results_tree.heading(col, text=col, command=lambda c=col: self.sort_results_by_column(c))
            self.results_tree.column(col, width=100)
        
        scrollbar_y = ttk.Scrollbar(results_frame, orient=tk.VERTICAL, command=self.results_tree.yview)
        scrollbar_x = ttk.Scrollbar(results_frame, orient=tk.HORIZONTAL, command=self.results_tree.xview)
        self.results_tree.configure(yscrollcommand=scrollbar_y.set, xscrollcommand=scrollbar_x.set)
        
        self.results_tree.grid(row=0, column=0, sticky="nsew")
        scrollbar_y.grid(row=0, column=1, sticky="ns")
        scrollbar_x.grid(row=1, column=0, sticky="ew")
        
        results_frame.grid_rowconfigure(0, weight=1)
        results_frame.grid_columnconfigure(0, weight=1)
        
        # 底部按钮区域
        button_frame = ttk.Frame(main_frame)
        button_frame.pack(fill=tk.X, pady=(10, 0))
        
        ttk.Button(button_frame, text="导出结果", command=self.export_results).pack(side=tk.LEFT)
        ttk.Button(button_frame, text="清除结果", command=self.clear_results).pack(side=tk.LEFT, padx=(5, 0))
        ttk.Button(button_frame, text="数据预览", command=self.preview_data).pack(side=tk.LEFT, padx=(5, 0))
        ttk.Button(button_frame, text="撤销操作", command=self.undo_operation).pack(side=tk.LEFT, padx=(5, 0))
        ttk.Button(button_frame, text="保存修改", command=self.save_changes).pack(side=tk.RIGHT)
        
        main_frame.rowconfigure(2, weight=1)
    
    # ==================== 原有功能标签页 ====================
    
    def setup_search_tab(self):
        """设置搜索功能标签页"""
        search_frame = ttk.Frame(self.function_notebook)
        self.function_notebook.add(search_frame, text="🔍 智能搜索")
        
        settings_frame = ttk.LabelFrame(search_frame, text="搜索设置", padding="5")
        settings_frame.pack(fill=tk.X, pady=5, padx=5)
        
        # 第一行：关键词输入
        row1 = ttk.Frame(settings_frame)
        row1.pack(fill=tk.X, pady=2)
        ttk.Label(row1, text="关键词:").pack(side=tk.LEFT, padx=(0, 5))
        self.search_var = tk.StringVar()
        ttk.Entry(row1, textvariable=self.search_var, width=40).pack(side=tk.LEFT, fill=tk.X, expand=True)
        
        # 第二行：搜索选项
        row2 = ttk.Frame(settings_frame)
        row2.pack(fill=tk.X, pady=2)
        
        ttk.Label(row2, text="匹配阈值(%):").pack(side=tk.LEFT, padx=(0, 5))
        self.threshold_var = tk.IntVar(value=70)
        ttk.Spinbox(row2, from_=0, to=100, textvariable=self.threshold_var, width=8).pack(side=tk.LEFT, padx=(0, 10))
        
        self.case_sensitive_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(row2, text="区分大小写", variable=self.case_sensitive_var).pack(side=tk.LEFT, padx=(0, 10))
        
        self.whole_word_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(row2, text="全词匹配", variable=self.whole_word_var).pack(side=tk.LEFT, padx=(0, 10))
        
        self.regex_search_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(row2, text="正则表达式", variable=self.regex_search_var).pack(side=tk.LEFT)
        
        # 第三行：搜索范围
        row3 = ttk.Frame(settings_frame)
        row3.pack(fill=tk.X, pady=2)
        
        ttk.Label(row3, text="搜索列(留空搜全部):").pack(side=tk.LEFT, padx=(0, 5))
        self.search_columns_var = tk.StringVar()
        ttk.Entry(row3, textvariable=self.search_columns_var, width=30).pack(side=tk.LEFT, padx=(0, 10))
        
        ttk.Button(row3, text="搜索", command=self.perform_search).pack(side=tk.RIGHT)
        ttk.Button(row3, text="高亮显示", command=self.highlight_search_results).pack(side=tk.RIGHT, padx=(0, 5))
    
    def setup_calculation_tab(self):
        """设置计算功能标签页"""
        calc_frame = ttk.Frame(self.function_notebook)
        self.function_notebook.add(calc_frame, text="🧮 求和计算")
        
        # 单元格求和
        cell_frame = ttk.LabelFrame(calc_frame, text="单元格求和", padding="5")
        cell_frame.pack(fill=tk.X, pady=5, padx=5)
        
        row1 = ttk.Frame(cell_frame)
        row1.pack(fill=tk.X, pady=2)
        ttk.Label(row1, text="单元格位置 (如: A2,B3,AA5):").pack(side=tk.LEFT, padx=(0, 5))
        self.cell_sum_var = tk.StringVar()
        ttk.Entry(row1, textvariable=self.cell_sum_var, width=40).pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 5))
        ttk.Button(row1, text="求和", command=self.calculate_cell_sum).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Button(row1, text="平均", command=lambda: self.calculate_cell_stats('mean')).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Button(row1, text="最大", command=lambda: self.calculate_cell_stats('max')).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Button(row1, text="最小", command=lambda: self.calculate_cell_stats('min')).pack(side=tk.LEFT)
        
        # 区域求和
        range_frame = ttk.LabelFrame(calc_frame, text="区域计算", padding="5")
        range_frame.pack(fill=tk.X, pady=5, padx=5)
        
        row2 = ttk.Frame(range_frame)
        row2.pack(fill=tk.X, pady=2)
        ttk.Label(row2, text="区域范围 (如: A2:C5):").pack(side=tk.LEFT, padx=(0, 5))
        self.range_sum_var = tk.StringVar()
        ttk.Entry(row2, textvariable=self.range_sum_var, width=20).pack(side=tk.LEFT, padx=(0, 5))
        
        self.range_calc_type = tk.StringVar(value="sum")
        ttk.Radiobutton(row2, text="求和", variable=self.range_calc_type, value="sum").pack(side=tk.LEFT)
        ttk.Radiobutton(row2, text="平均", variable=self.range_calc_type, value="mean").pack(side=tk.LEFT)
        ttk.Radiobutton(row2, text="计数", variable=self.range_calc_type, value="count").pack(side=tk.LEFT)
        ttk.Button(row2, text="计算", command=self.calculate_range_sum).pack(side=tk.RIGHT)
        
        # 条件求和
        cond_frame = ttk.LabelFrame(calc_frame, text="条件求和 (SUMIF)", padding="5")
        cond_frame.pack(fill=tk.X, pady=5, padx=5)
        
        row3 = ttk.Frame(cond_frame)
        row3.pack(fill=tk.X, pady=2)
        ttk.Label(row3, text="条件列:").pack(side=tk.LEFT, padx=(0, 5))
        self.cond_column_var = tk.StringVar()
        ttk.Entry(row3, textvariable=self.cond_column_var, width=15).pack(side=tk.LEFT, padx=(0, 10))
        
        ttk.Label(row3, text="运算符:").pack(side=tk.LEFT, padx=(0, 5))
        self.cond_operator_var = tk.StringVar(value="=")
        ttk.Combobox(row3, textvariable=self.cond_operator_var, values=["=", ">", "<", ">=", "<=", "!=", "包含", "开头", "结尾"], width=8).pack(side=tk.LEFT, padx=(0, 10))
        
        ttk.Label(row3, text="条件值:").pack(side=tk.LEFT, padx=(0, 5))
        self.condition_var = tk.StringVar()
        ttk.Entry(row3, textvariable=self.condition_var, width=15).pack(side=tk.LEFT, padx=(0, 10))
        
        row4 = ttk.Frame(cond_frame)
        row4.pack(fill=tk.X, pady=2)
        ttk.Label(row4, text="求和列:").pack(side=tk.LEFT, padx=(0, 5))
        self.sum_column_var = tk.StringVar()
        ttk.Entry(row4, textvariable=self.sum_column_var, width=15).pack(side=tk.LEFT, padx=(0, 10))
        ttk.Button(row4, text="计算", command=self.calculate_conditional_sum).pack(side=tk.RIGHT)
    
    def setup_analysis_tab(self):
        """设置分析功能标签页"""
        analysis_frame = ttk.Frame(self.function_notebook)
        self.function_notebook.add(analysis_frame, text="📊 数据分析")
        
        # 统计信息
        stats_frame = ttk.LabelFrame(analysis_frame, text="列统计分析", padding="5")
        stats_frame.pack(fill=tk.X, pady=5, padx=5)
        
        row1 = ttk.Frame(stats_frame)
        row1.pack(fill=tk.X, pady=2)
        ttk.Label(row1, text="选择列:").pack(side=tk.LEFT, padx=(0, 5))
        self.stats_column_var = tk.StringVar()
        self.stats_combo = ttk.Combobox(row1, textvariable=self.stats_column_var, width=25)
        self.stats_combo.pack(side=tk.LEFT, padx=(0, 5))
        ttk.Button(row1, text="分析", command=self.analyze_column).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Button(row1, text="全部列分析", command=self.analyze_all_columns).pack(side=tk.LEFT)
        
        # 重复值查找
        duplicate_frame = ttk.LabelFrame(analysis_frame, text="重复值处理", padding="5")
        duplicate_frame.pack(fill=tk.X, pady=5, padx=5)
        
        row2 = ttk.Frame(duplicate_frame)
        row2.pack(fill=tk.X, pady=2)
        ttk.Label(row2, text="检查列(逗号分隔):").pack(side=tk.LEFT, padx=(0, 5))
        self.dup_column_var = tk.StringVar()
        ttk.Entry(row2, textvariable=self.dup_column_var, width=25).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Button(row2, text="查找重复", command=self.find_duplicates).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Button(row2, text="删除重复", command=self.remove_duplicates).pack(side=tk.LEFT)
        
        # 数据验证
        validate_frame = ttk.LabelFrame(analysis_frame, text="数据验证", padding="5")
        validate_frame.pack(fill=tk.X, pady=5, padx=5)
        
        row3 = ttk.Frame(validate_frame)
        row3.pack(fill=tk.X, pady=2)
        ttk.Button(row3, text="检查空值", command=self.check_empty_cells).pack(side=tk.LEFT, padx=5)
        ttk.Button(row3, text="检查异常值", command=self.check_outliers).pack(side=tk.LEFT, padx=5)
        ttk.Button(row3, text="数据类型分析", command=self.analyze_data_types).pack(side=tk.LEFT, padx=5)
        ttk.Button(row3, text="数据质量报告", command=self.generate_quality_report).pack(side=tk.LEFT, padx=5)
    
    # ==================== 新增功能标签页 ====================
    
    def setup_filter_tab(self):
        """设置筛选功能标签页"""
        filter_frame = ttk.Frame(self.function_notebook)
        self.function_notebook.add(filter_frame, text="🔻 数据筛选")
        
        # 简单筛选
        simple_frame = ttk.LabelFrame(filter_frame, text="条件筛选", padding="5")
        simple_frame.pack(fill=tk.X, pady=5, padx=5)
        
        row1 = ttk.Frame(simple_frame)
        row1.pack(fill=tk.X, pady=2)
        ttk.Label(row1, text="筛选列:").pack(side=tk.LEFT, padx=(0, 5))
        self.filter_column_var = tk.StringVar()
        self.filter_column_combo = ttk.Combobox(row1, textvariable=self.filter_column_var, width=20)
        self.filter_column_combo.pack(side=tk.LEFT, padx=(0, 10))
        
        ttk.Label(row1, text="运算符:").pack(side=tk.LEFT, padx=(0, 5))
        self.filter_operator_var = tk.StringVar(value="=")
        ttk.Combobox(row1, textvariable=self.filter_operator_var, 
                     values=["=", "!=", ">", "<", ">=", "<=", "包含", "不包含", "开头", "结尾", "为空", "非空"], 
                     width=10).pack(side=tk.LEFT, padx=(0, 10))
        
        ttk.Label(row1, text="筛选值:").pack(side=tk.LEFT, padx=(0, 5))
        self.filter_value_var = tk.StringVar()
        ttk.Entry(row1, textvariable=self.filter_value_var, width=20).pack(side=tk.LEFT, padx=(0, 5))
        
        row2 = ttk.Frame(simple_frame)
        row2.pack(fill=tk.X, pady=2)
        ttk.Button(row2, text="应用筛选", command=self.apply_filter).pack(side=tk.LEFT, padx=5)
        ttk.Button(row2, text="取消筛选", command=self.clear_filter).pack(side=tk.LEFT, padx=5)
        ttk.Button(row2, text="导出筛选结果", command=self.export_filtered_data).pack(side=tk.LEFT, padx=5)
        
        # 多条件筛选
        multi_frame = ttk.LabelFrame(filter_frame, text="多条件筛选", padding="5")
        multi_frame.pack(fill=tk.X, pady=5, padx=5)
        
        row3 = ttk.Frame(multi_frame)
        row3.pack(fill=tk.X, pady=2)
        ttk.Label(row3, text="筛选表达式 (如: A>10 and B='是'):").pack(side=tk.LEFT, padx=(0, 5))
        self.multi_filter_var = tk.StringVar()
        ttk.Entry(row3, textvariable=self.multi_filter_var, width=50).pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 5))
        ttk.Button(row3, text="执行", command=self.apply_multi_filter).pack(side=tk.RIGHT)
        
        # 排序功能
        sort_frame = ttk.LabelFrame(filter_frame, text="数据排序", padding="5")
        sort_frame.pack(fill=tk.X, pady=5, padx=5)
        
        row4 = ttk.Frame(sort_frame)
        row4.pack(fill=tk.X, pady=2)
        ttk.Label(row4, text="排序列:").pack(side=tk.LEFT, padx=(0, 5))
        self.sort_column_var = tk.StringVar()
        self.sort_column_combo = ttk.Combobox(row4, textvariable=self.sort_column_var, width=20)
        self.sort_column_combo.pack(side=tk.LEFT, padx=(0, 10))
        
        self.sort_order_var = tk.StringVar(value="ascending")
        ttk.Radiobutton(row4, text="升序", variable=self.sort_order_var, value="ascending").pack(side=tk.LEFT, padx=5)
        ttk.Radiobutton(row4, text="降序", variable=self.sort_order_var, value="descending").pack(side=tk.LEFT, padx=5)
        ttk.Button(row4, text="排序", command=self.sort_data).pack(side=tk.RIGHT)
    
    def setup_transform_tab(self):
        """设置数据转换功能标签页"""
        transform_frame = ttk.Frame(self.function_notebook)
        self.function_notebook.add(transform_frame, text="🔄 数据转换")
        
        # 查找替换
        replace_frame = ttk.LabelFrame(transform_frame, text="查找替换", padding="5")
        replace_frame.pack(fill=tk.X, pady=5, padx=5)
        
        row1 = ttk.Frame(replace_frame)
        row1.pack(fill=tk.X, pady=2)
        ttk.Label(row1, text="目标列:").pack(side=tk.LEFT, padx=(0, 5))
        self.replace_column_var = tk.StringVar()
        self.replace_column_combo = ttk.Combobox(row1, textvariable=self.replace_column_var, width=15)
        self.replace_column_combo.pack(side=tk.LEFT, padx=(0, 10))
        
        ttk.Label(row1, text="查找:").pack(side=tk.LEFT, padx=(0, 5))
        self.find_text_var = tk.StringVar()
        ttk.Entry(row1, textvariable=self.find_text_var, width=15).pack(side=tk.LEFT, padx=(0, 10))
        
        ttk.Label(row1, text="替换为:").pack(side=tk.LEFT, padx=(0, 5))
        self.replace_text_var = tk.StringVar()
        ttk.Entry(row1, textvariable=self.replace_text_var, width=15).pack(side=tk.LEFT, padx=(0, 5))
        
        row2 = ttk.Frame(replace_frame)
        row2.pack(fill=tk.X, pady=2)
        self.replace_regex_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(row2, text="使用正则表达式", variable=self.replace_regex_var).pack(side=tk.LEFT, padx=5)
        ttk.Button(row2, text="替换全部", command=self.replace_all).pack(side=tk.RIGHT, padx=5)
        ttk.Button(row2, text="预览替换", command=self.preview_replace).pack(side=tk.RIGHT, padx=5)
        
        # 列操作
        column_frame = ttk.LabelFrame(transform_frame, text="列操作", padding="5")
        column_frame.pack(fill=tk.X, pady=5, padx=5)
        
        row3 = ttk.Frame(column_frame)
        row3.pack(fill=tk.X, pady=2)
        ttk.Button(row3, text="拆分列", command=self.split_column).pack(side=tk.LEFT, padx=5)
        ttk.Button(row3, text="合并列", command=self.merge_columns).pack(side=tk.LEFT, padx=5)
        ttk.Button(row3, text="重命名列", command=self.rename_column).pack(side=tk.LEFT, padx=5)
        ttk.Button(row3, text="删除列", command=self.delete_column).pack(side=tk.LEFT, padx=5)
        ttk.Button(row3, text="新增列", command=self.add_column).pack(side=tk.LEFT, padx=5)
        
        # 数据清洗
        clean_frame = ttk.LabelFrame(transform_frame, text="数据清洗", padding="5")
        clean_frame.pack(fill=tk.X, pady=5, padx=5)
        
        row4 = ttk.Frame(clean_frame)
        row4.pack(fill=tk.X, pady=2)
        ttk.Label(row4, text="目标列:").pack(side=tk.LEFT, padx=(0, 5))
        self.clean_column_var = tk.StringVar()
        self.clean_column_combo = ttk.Combobox(row4, textvariable=self.clean_column_var, width=15)
        self.clean_column_combo.pack(side=tk.LEFT, padx=(0, 10))
        
        ttk.Button(row4, text="去除空格", command=lambda: self.clean_data('strip')).pack(side=tk.LEFT, padx=5)
        ttk.Button(row4, text="转大写", command=lambda: self.clean_data('upper')).pack(side=tk.LEFT, padx=5)
        ttk.Button(row4, text="转小写", command=lambda: self.clean_data('lower')).pack(side=tk.LEFT, padx=5)
        ttk.Button(row4, text="填充空值", command=self.fill_empty_values).pack(side=tk.LEFT, padx=5)
    
    def setup_merge_tab(self):
        """设置数据合并功能标签页"""
        merge_frame = ttk.Frame(self.function_notebook)
        self.function_notebook.add(merge_frame, text="📎 数据合并")
        
        # VLOOKUP功能
        vlookup_frame = ttk.LabelFrame(merge_frame, text="VLOOKUP 数据匹配", padding="5")
        vlookup_frame.pack(fill=tk.X, pady=5, padx=5)
        
        row1 = ttk.Frame(vlookup_frame)
        row1.pack(fill=tk.X, pady=2)
        ttk.Label(row1, text="查找值所在列:").pack(side=tk.LEFT, padx=(0, 5))
        self.vlookup_key_var = tk.StringVar()
        ttk.Entry(row1, textvariable=self.vlookup_key_var, width=15).pack(side=tk.LEFT, padx=(0, 10))
        
        ttk.Label(row1, text="匹配文件:").pack(side=tk.LEFT, padx=(0, 5))
        self.vlookup_file_var = tk.StringVar()
        ttk.Entry(row1, textvariable=self.vlookup_file_var, width=25).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Button(row1, text="浏览", command=self.browse_vlookup_file).pack(side=tk.LEFT)
        
        row2 = ttk.Frame(vlookup_frame)
        row2.pack(fill=tk.X, pady=2)
        ttk.Label(row2, text="匹配列:").pack(side=tk.LEFT, padx=(0, 5))
        self.vlookup_match_var = tk.StringVar()
        ttk.Entry(row2, textvariable=self.vlookup_match_var, width=15).pack(side=tk.LEFT, padx=(0, 10))
        
        ttk.Label(row2, text="返回列:").pack(side=tk.LEFT, padx=(0, 5))
        self.vlookup_return_var = tk.StringVar()
        ttk.Entry(row2, textvariable=self.vlookup_return_var, width=15).pack(side=tk.LEFT, padx=(0, 10))
        ttk.Button(row2, text="执行匹配", command=self.perform_vlookup).pack(side=tk.RIGHT)
        
        # 文件合并
        file_merge_frame = ttk.LabelFrame(merge_frame, text="多文件合并", padding="5")
        file_merge_frame.pack(fill=tk.X, pady=5, padx=5)
        
        row3 = ttk.Frame(file_merge_frame)
        row3.pack(fill=tk.X, pady=2)
        ttk.Button(row3, text="选择要合并的文件", command=self.select_merge_files).pack(side=tk.LEFT, padx=5)
        
        self.merge_type_var = tk.StringVar(value="vertical")
        ttk.Radiobutton(row3, text="纵向合并(追加行)", variable=self.merge_type_var, value="vertical").pack(side=tk.LEFT, padx=10)
        ttk.Radiobutton(row3, text="横向合并(追加列)", variable=self.merge_type_var, value="horizontal").pack(side=tk.LEFT, padx=10)
        
        self.merge_files_list = []
        
        row4 = ttk.Frame(file_merge_frame)
        row4.pack(fill=tk.X, pady=2)
        ttk.Label(row4, text="已选择文件:").pack(side=tk.LEFT, padx=(0, 5))
        self.merge_files_label = ttk.Label(row4, text="未选择", foreground="gray")
        self.merge_files_label.pack(side=tk.LEFT, padx=(0, 10))
        ttk.Button(row4, text="执行合并", command=self.merge_files).pack(side=tk.RIGHT)
        
        # 分组汇总
        group_frame = ttk.LabelFrame(merge_frame, text="分组汇总 (数据透视)", padding="5")
        group_frame.pack(fill=tk.X, pady=5, padx=5)
        
        row5 = ttk.Frame(group_frame)
        row5.pack(fill=tk.X, pady=2)
        ttk.Label(row5, text="分组列:").pack(side=tk.LEFT, padx=(0, 5))
        self.group_column_var = tk.StringVar()
        ttk.Entry(row5, textvariable=self.group_column_var, width=20).pack(side=tk.LEFT, padx=(0, 10))
        
        ttk.Label(row5, text="汇总列:").pack(side=tk.LEFT, padx=(0, 5))
        self.agg_column_var = tk.StringVar()
        ttk.Entry(row5, textvariable=self.agg_column_var, width=15).pack(side=tk.LEFT, padx=(0, 10))
        
        ttk.Label(row5, text="汇总方式:").pack(side=tk.LEFT, padx=(0, 5))
        self.agg_func_var = tk.StringVar(value="sum")
        ttk.Combobox(row5, textvariable=self.agg_func_var, values=["sum", "mean", "count", "max", "min", "std"], width=10).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Button(row5, text="执行", command=self.group_and_aggregate).pack(side=tk.RIGHT)
    
    # ==================== 文件操作方法 ====================
    
    def browse_file(self):
        """浏览选择Excel文件"""
        file_path = filedialog.askopenfilename(
            title="选择Excel文件",
            filetypes=[("Excel Files", "*.xlsx *.xls"), ("CSV Files", "*.csv"), ("All Files", "*.*")]
        )
        
        if file_path:
            self.file_var.set(file_path)
            self.load_excel_file(file_path)
    
    def load_excel_file(self, file_path):
        """加载Excel文件并支持sheet选择"""
        try:
            if file_path.endswith('.csv'):
                df = pd.read_csv(file_path, encoding='utf-8-sig')
                self.current_df = df
                self.original_df = df.copy()
                self.current_file = file_path
                self.current_sheet_name = "CSV"
            else:
                excel_file = pd.ExcelFile(file_path)
                sheet_names = excel_file.sheet_names
                
                selected_sheet = None
                if len(sheet_names) == 1:
                    selected_sheet = sheet_names[0]
                else:
                    selected_sheet = self.show_sheet_selection_dialog(sheet_names)

                if selected_sheet:
                    df = pd.read_excel(file_path, sheet_name=selected_sheet, header=None)
                    
                    if not df.empty:
                        new_headers = df.iloc[0]
                        df = df[1:]
                        df.columns = new_headers
                        df.reset_index(drop=True, inplace=True)
                    
                    self.current_df = df
                    self.original_df = df.copy()
                    self.current_file = file_path
                    self.current_sheet_name = selected_sheet
                else:
                    self.status_bar.set_status("用户取消加载文件。")
                    return
            
            # 更新所有下拉框
            self.update_column_combos()
            
            columns = list(self.current_df.columns)
            sheet_info = f" (工作表: '{self.current_sheet_name}')" if self.current_sheet_name else ""
            self.status_bar.set_status(f"文件加载成功{sheet_info}，共 {len(self.current_df)} 行，{len(columns)} 列")
            
        except Exception as e:
            messagebox.showerror("错误", f"加载文件失败: {str(e)}")
            self.status_bar.set_status(f"加载失败: {e}")
    
    def update_column_combos(self):
        """更新所有列选择下拉框"""
        if self.current_df is not None:
            columns = [str(col) for col in self.current_df.columns]
            for combo in [self.stats_combo, self.filter_column_combo, self.sort_column_combo, 
                         self.replace_column_combo, self.clean_column_combo]:
                if hasattr(self, combo.winfo_name()) or combo.winfo_exists():
                    combo["values"] = columns
    
    def reload_file(self):
        """重新加载当前文件"""
        if self.current_file:
            self.load_excel_file(self.current_file)
        else:
            messagebox.showwarning("警告", "没有已加载的文件")
    
    def switch_sheet(self):
        """切换工作表"""
        if not self.current_file or self.current_file.endswith('.csv'):
            messagebox.showwarning("警告", "当前文件不支持切换工作表")
            return
        
        try:
            excel_file = pd.ExcelFile(self.current_file)
            sheet_names = excel_file.sheet_names
            
            if len(sheet_names) <= 1:
                messagebox.showinfo("提示", "当前文件只有一个工作表")
                return
            
            selected_sheet = self.show_sheet_selection_dialog(sheet_names)
            if selected_sheet:
                df = pd.read_excel(self.current_file, sheet_name=selected_sheet, header=None)
                if not df.empty:
                    new_headers = df.iloc[0]
                    df = df[1:]
                    df.columns = new_headers
                    df.reset_index(drop=True, inplace=True)
                
                self.current_df = df
                self.original_df = df.copy()
                self.current_sheet_name = selected_sheet
                self.update_column_combos()
                self.status_bar.set_status(f"已切换到工作表: '{selected_sheet}'")
                
        except Exception as e:
            messagebox.showerror("错误", f"切换工作表失败: {str(e)}")

    def show_sheet_selection_dialog(self, sheet_names):
        """显示sheet选择对话框"""
        dialog = tk.Toplevel(self.tab_frame)
        dialog.title("选择工作表")
        
        win_width = 300
        win_height = 250
        screen_width = dialog.winfo_screenwidth()
        screen_height = dialog.winfo_screenheight()
        x = int((screen_width - win_width) / 2)
        y = int((screen_height - win_height) / 2)
        dialog.geometry(f"{win_width}x{win_height}+{x}+{y}")
        
        dialog.transient(self.tab_frame)
        dialog.grab_set()
        
        ttk.Label(dialog, text="该文件包含多个工作表，请选择一个：", padding="10").pack()
        
        result = [None]
        
        listbox = tk.Listbox(dialog, selectmode=tk.SINGLE, exportselection=False)
        for sheet in sheet_names:
            listbox.insert(tk.END, sheet)
        listbox.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)
        listbox.selection_set(0)
        
        def on_ok():
            selection = listbox.curselection()
            if selection:
                result[0] = listbox.get(selection[0])
            dialog.destroy()
        
        def on_cancel():
            result[0] = None
            dialog.destroy()

        def on_double_click(event):
            on_ok()

        listbox.bind("<Double-Button-1>", on_double_click)
        
        button_frame = ttk.Frame(dialog)
        button_frame.pack(fill=tk.X, padx=10, pady=10)
        
        ok_button = ttk.Button(button_frame, text="确定", command=on_ok)
        ok_button.pack(side=tk.RIGHT, padx=(5, 0))
        cancel_button = ttk.Button(button_frame, text="取消", command=on_cancel)
        cancel_button.pack(side=tk.RIGHT)
        
        dialog.bind("<Return>", lambda event: on_ok())
        dialog.wait_window()
        
        return result[0]
    
    def save_changes(self):
        """保存修改到文件"""
        if not self.check_file_loaded():
            return
        
        try:
            file_path = filedialog.asksaveasfilename(
                defaultextension=".xlsx",
                filetypes=[("Excel Files", "*.xlsx"), ("CSV Files", "*.csv")],
                initialfile=f"modified_{self.current_sheet_name or 'data'}"
            )
            
            if file_path:
                if file_path.endswith('.csv'):
                    self.current_df.to_csv(file_path, index=False, encoding='utf-8-sig')
                else:
                    self.current_df.to_excel(file_path, index=False, sheet_name=self.current_sheet_name or 'Sheet1')
                
                messagebox.showinfo("成功", f"文件已保存: {file_path}")
                self.status_bar.set_status(f"文件已保存: {file_path}")
                
        except Exception as e:
            messagebox.showerror("错误", f"保存失败: {str(e)}")
    
    def save_state(self):
        """保存当前状态用于撤销"""
        if self.current_df is not None:
            self.history_stack.append(self.current_df.copy())
            if len(self.history_stack) > 10:  # 最多保存10步
                self.history_stack.pop(0)
    
    def undo_operation(self):
        """撤销上一次操作"""
        if self.history_stack:
            self.current_df = self.history_stack.pop()
            self.update_column_combos()
            self.status_bar.set_status("已撤销上一次操作")
        else:
            messagebox.showinfo("提示", "没有可撤销的操作")
    
    # ==================== 搜索功能方法 ====================
    
    def perform_search(self):
        """执行搜索"""
        if not self.check_file_loaded():
            return
        
        keyword = self.search_var.get().strip()
        if not keyword:
            messagebox.showwarning("警告", "请输入搜索关键词")
            return
        
        try:
            threshold = self.threshold_var.get() / 100.0
            case_sensitive = self.case_sensitive_var.get()
            whole_word = self.whole_word_var.get()
            use_regex = self.regex_search_var.get()
            
            # 确定搜索列
            search_cols_str = self.search_columns_var.get().strip()
            if search_cols_str:
                search_columns = [col.strip() for col in search_cols_str.split(',')]
            else:
                search_columns = list(self.current_df.columns)
            
            results = []
            search_keyword = keyword if case_sensitive else keyword.lower()
            
            for col in search_columns:
                if col not in self.current_df.columns:
                    continue
                    
                for row_idx, value in self.current_df[col].items():
                    if pd.notna(value):
                        str_value = str(value)
                        search_value = str_value if case_sensitive else str_value.lower()
                        
                        match = False
                        if use_regex:
                            try:
                                flags = 0 if case_sensitive else re.IGNORECASE
                                match = bool(re.search(keyword, str_value, flags))
                            except re.error:
                                pass
                        elif whole_word:
                            match = search_keyword == search_value
                        else:
                            match = search_keyword in search_value
                        
                        if match:
                            # 计算相似度
                            set_kw = set(search_keyword)
                            set_val = set(search_value)
                            similarity = len(set_kw & set_val) / len(set_kw | set_val) if len(set_kw | set_val) > 0 else 0
                            
                            if similarity >= threshold:
                                results.append({
                                    "行": row_idx + 2,
                                    "列": col,
                                    "内容": str_value[:100],
                                    "附加信息": f"相似度: {similarity:.2%}"
                                })
            
            self.display_results(results)
            self.status_bar.set_status(f"搜索完成，找到 {len(results)} 个结果")
            
        except Exception as e:
            messagebox.showerror("错误", f"搜索失败: {str(e)}")
    
    def highlight_search_results(self):
        """高亮显示搜索结果（在预览中标记）"""
        if not self.search_results:
            messagebox.showwarning("警告", "请先执行搜索")
            return
        
        # 创建标记列
        if self.current_df is not None:
            self.save_state()
            self.current_df['_搜索标记'] = ''
            for result in self.search_results:
                row_idx = result['行'] - 2
                if 0 <= row_idx < len(self.current_df):
                    self.current_df.loc[row_idx, '_搜索标记'] = '★'
            
            self.status_bar.set_status(f"已标记 {len(self.search_results)} 个搜索结果")
    
    # ==================== 计算功能方法 ====================
    
    def parse_cell_reference(self, cell_ref):
        """解析单元格引用"""
        match = re.match(r'^([A-Za-z]+)(\d+)$', cell_ref.strip())
        if not match:
            raise ValueError(f"无效的单元格引用格式: '{cell_ref}'")
        
        col_letters = match.group(1).upper()
        row_str = match.group(2)
        
        col_idx = 0
        for char in col_letters:
            col_idx = col_idx * 26 + (ord(char) - ord('A') + 1)
        col_idx -= 1
        
        row_idx = int(row_str) - 2
        
        if row_idx < 0:
            raise ValueError(f"行号无效: '{row_str}'。数据行从第2行开始。")

        return col_idx, row_idx
    
    def get_cell_value(self, cell_ref):
        """获取单元格值"""
        try:
            col_idx, row_idx = self.parse_cell_reference(cell_ref)
            if 0 <= row_idx < len(self.current_df) and 0 <= col_idx < len(self.current_df.columns):
                return self.current_df.iloc[row_idx, col_idx]
            return None
        except ValueError as e:
            return None
    
    def calculate_cell_sum(self):
        """计算指定单元格之和"""
        if not self.check_file_loaded():
            return
        
        cell_refs = self.cell_sum_var.get().strip()
        if not cell_refs:
            messagebox.showwarning("警告", "请输入单元格位置")
            return
        
        try:
            cells = [cell.strip() for cell in cell_refs.split(",") if cell.strip()]
            total = 0
            cell_values = []
            
            for cell in cells:
                value = self.get_cell_value(cell)
                if value is not None:
                    try:
                        numeric_value = float(value)
                        total += numeric_value
                        cell_values.append(f"{cell}: {numeric_value}")
                    except (ValueError, TypeError):
                        cell_values.append(f"{cell}: '{value}' (非数值)")
                else:
                    cell_values.append(f"{cell}: (空或无效地址)")

            self.display_results([{
                "行": "汇总", 
                "列": "结果", 
                "内容": str(total), 
                "附加信息": "; ".join(cell_values)
            }])
            self.status_bar.set_status(f"单元格求和完成: {total}")
            
        except Exception as e:
            messagebox.showerror("错误", f"计算失败: {str(e)}")
    
    def calculate_cell_stats(self, stat_type: str):
        """计算指定单元格的统计值"""
        if not self.check_file_loaded():
            return
        
        cell_refs = self.cell_sum_var.get().strip()
        if not cell_refs:
            messagebox.showwarning("警告", "请输入单元格位置")
            return
        
        try:
            cells = [cell.strip() for cell in cell_refs.split(",") if cell.strip()]
            values = []
            
            for cell in cells:
                value = self.get_cell_value(cell)
                if value is not None:
                    try:
                        values.append(float(value))
                    except (ValueError, TypeError):
                        pass
            
            if not values:
                messagebox.showwarning("警告", "没有有效的数值")
                return
            
            if stat_type == 'mean':
                result = sum(values) / len(values)
                label = "平均值"
            elif stat_type == 'max':
                result = max(values)
                label = "最大值"
            elif stat_type == 'min':
                result = min(values)
                label = "最小值"
            else:
                return
            
            self.display_results([{
                "行": "计算", 
                "列": label, 
                "内容": f"{result:.4f}", 
                "附加信息": f"有效数值: {len(values)} 个"
            }])
            self.status_bar.set_status(f"{label}: {result:.4f}")
            
        except Exception as e:
            messagebox.showerror("错误", f"计算失败: {str(e)}")
    
    def calculate_range_sum(self):
        """计算指定区域的统计值"""
        if not self.check_file_loaded():
            return
        
        range_ref = self.range_sum_var.get().strip()
        if not range_ref:
            messagebox.showwarning("警告", "请输入区域范围")
            return
        
        try:
            start_cell, end_cell = range_ref.split(":")
            start_col, start_row = self.parse_cell_reference(start_cell)
            end_col, end_row = self.parse_cell_reference(end_cell)
            
            values = []
            max_row = len(self.current_df)
            max_col = len(self.current_df.columns)

            for row_idx in range(start_row, min(end_row + 1, max_row)):
                for col_idx in range(start_col, min(end_col + 1, max_col)):
                    value = self.current_df.iloc[row_idx, col_idx]
                    if pd.notna(value):
                        try:
                            values.append(float(value))
                        except (ValueError, TypeError):
                            continue
            
            calc_type = self.range_calc_type.get()
            if calc_type == 'sum':
                result = sum(values) if values else 0
                label = "求和"
            elif calc_type == 'mean':
                result = sum(values) / len(values) if values else 0
                label = "平均值"
            elif calc_type == 'count':
                result = len(values)
                label = "计数"
            else:
                return
            
            self.display_results([{
                "行": "区域计算", 
                "列": label, 
                "内容": f"{result:.4f}" if isinstance(result, float) else str(result), 
                "附加信息": f"区域: {range_ref}, 有效单元格: {len(values)}"
            }])
            self.status_bar.set_status(f"区域{label}: {result}")
            
        except ValueError as e:
            messagebox.showerror("错误", f"区域范围格式错误: {e}")
        except Exception as e:
            messagebox.showerror("错误", f"计算失败: {str(e)}")
    
    def calculate_conditional_sum(self):
        """条件求和（支持多种运算符）"""
        if not self.check_file_loaded():
            return
            
        cond_column = self.cond_column_var.get().strip()
        operator = self.cond_operator_var.get()
        condition = self.condition_var.get().strip()
        sum_column = self.sum_column_var.get().strip()
        
        if not all([cond_column, condition, sum_column]):
            messagebox.showwarning("警告", "请填写完整的条件求和参数")
            return

        if cond_column not in self.current_df.columns or sum_column not in self.current_df.columns:
            messagebox.showerror("错误", f"列名不存在，请检查。\n可用列: {list(self.current_df.columns)}")
            return

        try:
            cond_series = self.current_df[cond_column]
            
            # 根据运算符创建掩码
            if operator == "=":
                mask = cond_series.astype(str) == condition
            elif operator == "!=":
                mask = cond_series.astype(str) != condition
            elif operator in [">", "<", ">=", "<="]:
                try:
                    numeric_cond = pd.to_numeric(cond_series, errors='coerce')
                    condition_val = float(condition)
                    if operator == ">":
                        mask = numeric_cond > condition_val
                    elif operator == "<":
                        mask = numeric_cond < condition_val
                    elif operator == ">=":
                        mask = numeric_cond >= condition_val
                    else:
                        mask = numeric_cond <= condition_val
                except ValueError:
                    messagebox.showerror("错误", "使用数值比较运算符时，条件值必须为数字")
                    return
            elif operator == "包含":
                mask = cond_series.astype(str).str.contains(condition, na=False)
            elif operator == "开头":
                mask = cond_series.astype(str).str.startswith(condition, na=False)
            elif operator == "结尾":
                mask = cond_series.astype(str).str.endswith(condition, na=False)
            else:
                mask = cond_series.astype(str) == condition
            
            sum_series = pd.to_numeric(self.current_df[sum_column], errors='coerce')
            total = sum_series[mask].sum()
            count = mask.sum()
            
            self.display_results([{
                "行": "条件求和", 
                "列": "结果", 
                "内容": str(total), 
                "附加信息": f"条件: {cond_column} {operator} '{condition}', 满足条件: {count} 行"
            }])
            self.status_bar.set_status(f"条件求和完成: {total}")
            
        except Exception as e:
            messagebox.showerror("错误", f"计算失败: {str(e)}")
    
    # ==================== 分析功能方法 ====================
    
    def analyze_column(self):
        """分析单列统计信息"""
        if not self.check_file_loaded():
            return
        
        column = self.stats_column_var.get()
        if not column or column not in self.current_df.columns:
            messagebox.showwarning("警告", "请选择有效的列")
            return
        
        try:
            series = self.current_df[column]
            stats_list = []
            
            # 基本统计
            stats_list.extend([
                {"行": "统计", "列": column, "内容": "总数", "附加信息": f"{series.size}"},
                {"行": "统计", "列": column, "内容": "非空值数", "附加信息": f"{series.count()}"},
                {"行": "统计", "列": column, "内容": "空值数", "附加信息": f"{series.isnull().sum()}"},
                {"行": "统计", "列": column, "内容": "唯一值数", "附加信息": f"{series.nunique()}"}
            ])
            
            # 数值统计
            numeric_series = pd.to_numeric(series, errors='coerce')
            if not numeric_series.isnull().all():
                stats_list.extend([
                    {"行": "统计", "列": column, "内容": "合计", "附加信息": f"{numeric_series.sum():.4f}"},
                    {"行": "统计", "列": column, "内容": "平均值", "附加信息": f"{numeric_series.mean():.4f}"},
                    {"行": "统计", "列": column, "内容": "标准差", "附加信息": f"{numeric_series.std():.4f}"},
                    {"行": "统计", "列": column, "内容": "最小值", "附加信息": f"{numeric_series.min()}"},
                    {"行": "统计", "列": column, "内容": "25%分位数", "附加信息": f"{numeric_series.quantile(0.25)}"},
                    {"行": "统计", "列": column, "内容": "中位数", "附加信息": f"{numeric_series.median()}"},
                    {"行": "统计", "列": column, "内容": "75%分位数", "附加信息": f"{numeric_series.quantile(0.75)}"},
                    {"行": "统计", "列": column, "内容": "最大值", "附加信息": f"{numeric_series.max()}"}
                ])
            
            # 众数
            mode_values = series.mode()
            if not mode_values.empty:
                stats_list.append({
                    "行": "统计", "列": column, "内容": "众数", 
                    "附加信息": str(mode_values.iloc[0])
                })
            
            self.display_results(stats_list)
            self.status_bar.set_status(f"列 '{column}' 分析完成")
            
        except Exception as e:
            messagebox.showerror("错误", f"分析失败: {str(e)}")
    
    def analyze_all_columns(self):
        """分析所有列的基本统计"""
        if not self.check_file_loaded():
            return
        
        try:
            results = []
            for col in self.current_df.columns:
                series = self.current_df[col]
                numeric_series = pd.to_numeric(series, errors='coerce')
                
                is_numeric = not numeric_series.isnull().all()
                col_type = "数值" if is_numeric else "文本"
                
                info = f"非空: {series.count()}, 唯一: {series.nunique()}"
                if is_numeric:
                    info += f", 均值: {numeric_series.mean():.2f}"
                
                results.append({
                    "行": "全列分析",
                    "列": str(col),
                    "内容": col_type,
                    "附加信息": info
                })
            
            self.display_results(results)
            self.status_bar.set_status(f"全部 {len(results)} 列分析完成")
            
        except Exception as e:
            messagebox.showerror("错误", f"分析失败: {str(e)}")
    
    def find_duplicates(self):
        """查找重复值"""
        if not self.check_file_loaded():
            return
        
        columns_str = self.dup_column_var.get().strip()
        if not columns_str:
            messagebox.showwarning("警告", "请输入要检查的列名")
            return
        
        columns = [col.strip() for col in columns_str.split(',')]
        missing_cols = [col for col in columns if col not in self.current_df.columns]
        if missing_cols:
            messagebox.showerror("错误", f"以下列不存在: {', '.join(missing_cols)}")
            return
        
        try:
            duplicates = self.current_df[self.current_df.duplicated(subset=columns, keep=False)]
            results = []
            for idx, row in duplicates.iterrows():
                results.append({
                    "行": idx + 2,
                    "列": ", ".join(columns),
                    "内容": str({col: row[col] for col in columns}),
                    "附加信息": "重复值"
                })
            
            self.display_results(results)
            if results:
                self.status_bar.set_status(f"找到 {len(duplicates)} 行重复记录")
            else:
                self.status_bar.set_status("未找到重复值")
                
        except Exception as e:
            messagebox.showerror("错误", f"查找失败: {str(e)}")
    
    def remove_duplicates(self):
        """删除重复值"""
        if not self.check_file_loaded():
            return
        
        columns_str = self.dup_column_var.get().strip()
        if not columns_str:
            # 如果没有指定列，按全部列去重
            columns = None
        else:
            columns = [col.strip() for col in columns_str.split(',')]
            missing_cols = [col for col in columns if col not in self.current_df.columns]
            if missing_cols:
                messagebox.showerror("错误", f"以下列不存在: {', '.join(missing_cols)}")
                return
        
        try:
            original_count = len(self.current_df)
            self.save_state()
            
            if columns:
                self.current_df = self.current_df.drop_duplicates(subset=columns, keep='first')
            else:
                self.current_df = self.current_df.drop_duplicates(keep='first')
            
            self.current_df.reset_index(drop=True, inplace=True)
            removed_count = original_count - len(self.current_df)
            
            messagebox.showinfo("完成", f"已删除 {removed_count} 行重复数据")
            self.status_bar.set_status(f"删除重复完成，移除 {removed_count} 行")
            
        except Exception as e:
            messagebox.showerror("错误", f"删除重复失败: {str(e)}")
    
    def check_empty_cells(self):
        """检查空值"""
        if not self.check_file_loaded():
            return
        
        try:
            results = []
            for col in self.current_df.columns:
                empty_count = self.current_df[col].isnull().sum()
                if empty_count > 0:
                    empty_rate = empty_count / len(self.current_df)
                    results.append({
                        "行": "空值统计",
                        "列": str(col),
                        "内容": f"空值数量: {empty_count}",
                        "附加信息": f"空值率: {empty_rate:.2%}"
                    })
            
            self.display_results(results)
            if results:
                self.status_bar.set_status(f"空值检查完成，{len(results)} 列有空值")
            else:
                self.status_bar.set_status("未发现空值")
                
        except Exception as e:
            messagebox.showerror("错误", f"检查失败: {str(e)}")
    
    def check_outliers(self):
        """检查异常值（使用IQR方法）"""
        if not self.check_file_loaded():
            return
        
        try:
            results = []
            for col in self.current_df.columns:
                numeric_series = pd.to_numeric(self.current_df[col], errors='coerce').dropna()
                
                if len(numeric_series) > 0:
                    Q1 = numeric_series.quantile(0.25)
                    Q3 = numeric_series.quantile(0.75)
                    IQR = Q3 - Q1
                    
                    lower_bound = Q1 - 1.5 * IQR
                    upper_bound = Q3 + 1.5 * IQR
                    
                    outliers = numeric_series[(numeric_series < lower_bound) | (numeric_series > upper_bound)]
                    
                    if len(outliers) > 0:
                        results.append({
                            "行": "异常值检测",
                            "列": str(col),
                            "内容": f"异常值数量: {len(outliers)}",
                            "附加信息": f"范围: [{lower_bound:.2f}, {upper_bound:.2f}], 异常值: {outliers.head(5).tolist()}"
                        })
            
            self.display_results(results)
            if results:
                self.status_bar.set_status(f"异常值检测完成，{len(results)} 列有异常值")
            else:
                self.status_bar.set_status("未发现明显异常值")
                
        except Exception as e:
            messagebox.showerror("错误", f"检测失败: {str(e)}")
    
    def analyze_data_types(self):
        """分析数据类型"""
        if not self.check_file_loaded():
            return
        
        try:
            results = []
            for col in self.current_df.columns:
                dtype = str(self.current_df[col].dtype)
                non_null = self.current_df[col].dropna()
                
                # 推断实际数据类型
                inferred_type = "未知"
                if not non_null.empty:
                    sample = non_null.iloc[0]
                    if pd.api.types.is_numeric_dtype(self.current_df[col]):
                        inferred_type = "数值"
                    elif pd.api.types.is_datetime64_any_dtype(self.current_df[col]):
                        inferred_type = "日期时间"
                    elif isinstance(sample, str):
                        # 尝试解析为日期
                        try:
                            pd.to_datetime(non_null.head(10))
                            inferred_type = "日期字符串"
                        except:
                            inferred_type = "文本"
                    else:
                        inferred_type = "其他"
                
                sample_value = str(non_null.iloc[0])[:50] if not non_null.empty else ""
                results.append({
                    "行": "数据类型",
                    "列": str(col),
                    "内容": f"{dtype} ({inferred_type})",
                    "附加信息": f"样本: {sample_value}"
                })
            
            self.display_results(results)
            self.status_bar.set_status(f"数据类型分析完成")
            
        except Exception as e:
            messagebox.showerror("错误", f"分析失败: {str(e)}")
    
    def generate_quality_report(self):
        """生成数据质量报告"""
        if not self.check_file_loaded():
            return
        
        try:
            results = []
            total_cells = len(self.current_df) * len(self.current_df.columns)
            total_empty = self.current_df.isnull().sum().sum()
            
            # 总体统计
            results.append({
                "行": "数据质量",
                "列": "总体",
                "内容": f"行数: {len(self.current_df)}, 列数: {len(self.current_df.columns)}",
                "附加信息": f"总单元格: {total_cells}, 空值: {total_empty} ({total_empty/total_cells:.2%})"
            })
            
            # 完整性评分
            completeness = (total_cells - total_empty) / total_cells * 100
            results.append({
                "行": "数据质量",
                "列": "完整性",
                "内容": f"{completeness:.1f}%",
                "附加信息": "数据填充率"
            })
            
            # 重复行统计
            dup_count = self.current_df.duplicated().sum()
            results.append({
                "行": "数据质量",
                "列": "唯一性",
                "内容": f"重复行: {dup_count}",
                "附加信息": f"重复率: {dup_count/len(self.current_df):.2%}"
            })
            
            self.display_results(results)
            self.status_bar.set_status("数据质量报告生成完成")
            
        except Exception as e:
            messagebox.showerror("错误", f"生成报告失败: {str(e)}")
    
    # ==================== 筛选功能方法 ====================
    
    def apply_filter(self):
        """应用筛选条件"""
        if not self.check_file_loaded():
            return
        
        column = self.filter_column_var.get()
        operator = self.filter_operator_var.get()
        value = self.filter_value_var.get()
        
        if not column:
            messagebox.showwarning("警告", "请选择筛选列")
            return
        
        if column not in self.current_df.columns:
            messagebox.showerror("错误", f"列 '{column}' 不存在")
            return
        
        try:
            self.save_state()
            series = self.current_df[column]
            
            if operator == "=":
                mask = series.astype(str) == value
            elif operator == "!=":
                mask = series.astype(str) != value
            elif operator in [">", "<", ">=", "<="]:
                numeric = pd.to_numeric(series, errors='coerce')
                val = float(value)
                if operator == ">":
                    mask = numeric > val
                elif operator == "<":
                    mask = numeric < val
                elif operator == ">=":
                    mask = numeric >= val
                else:
                    mask = numeric <= val
            elif operator == "包含":
                mask = series.astype(str).str.contains(value, na=False)
            elif operator == "不包含":
                mask = ~series.astype(str).str.contains(value, na=False)
            elif operator == "开头":
                mask = series.astype(str).str.startswith(value, na=False)
            elif operator == "结尾":
                mask = series.astype(str).str.endswith(value, na=False)
            elif operator == "为空":
                mask = series.isnull()
            elif operator == "非空":
                mask = series.notnull()
            else:
                mask = series.astype(str) == value
            
            filtered_df = self.current_df[mask]
            
            results = []
            for idx, row in filtered_df.head(100).iterrows():
                results.append({
                    "行": idx + 2,
                    "列": "筛选结果",
                    "内容": str(row.to_dict())[:100],
                    "附加信息": f"满足条件: {column} {operator} {value}"
                })
            
            self.display_results(results)
            self.status_bar.set_status(f"筛选完成，共 {len(filtered_df)} 行满足条件")
            
            # 询问是否应用筛选
            if messagebox.askyesno("确认", f"找到 {len(filtered_df)} 行数据，是否仅保留这些数据？"):
                self.current_df = filtered_df.reset_index(drop=True)
                self.status_bar.set_status(f"已应用筛选，保留 {len(self.current_df)} 行")
            
        except Exception as e:
            messagebox.showerror("错误", f"筛选失败: {str(e)}")
    
    def clear_filter(self):
        """取消筛选，恢复原始数据"""
        if self.original_df is not None:
            self.current_df = self.original_df.copy()
            self.update_column_combos()
            self.status_bar.set_status("已恢复原始数据")
        else:
            messagebox.showwarning("警告", "没有原始数据可恢复")
    
    def export_filtered_data(self):
        """导出当前数据（筛选后）"""
        if not self.check_file_loaded():
            return
        
        try:
            file_path = filedialog.asksaveasfilename(
                defaultextension=".xlsx",
                filetypes=[("Excel Files", "*.xlsx"), ("CSV Files", "*.csv")],
                initialfile="filtered_data"
            )
            
            if file_path:
                if file_path.endswith('.csv'):
                    self.current_df.to_csv(file_path, index=False, encoding='utf-8-sig')
                else:
                    self.current_df.to_excel(file_path, index=False)
                
                messagebox.showinfo("成功", f"已导出 {len(self.current_df)} 行数据到: {file_path}")
                
        except Exception as e:
            messagebox.showerror("错误", f"导出失败: {str(e)}")
    
    def apply_multi_filter(self):
        """应用多条件筛选（使用pandas query）"""
        if not self.check_file_loaded():
            return
        
        expression = self.multi_filter_var.get().strip()
        if not expression:
            messagebox.showwarning("警告", "请输入筛选表达式")
            return
        
        try:
            self.save_state()
            
            # 简单预处理表达式
            # 将中文运算符转换为英文
            expression = expression.replace('且', ' and ').replace('或', ' or ').replace('非', ' not ')
            
            filtered_df = self.current_df.query(expression)
            
            results = []
            for idx, row in filtered_df.head(100).iterrows():
                results.append({
                    "行": idx + 2,
                    "列": "多条件筛选",
                    "内容": str(row.to_dict())[:100],
                    "附加信息": expression
                })
            
            self.display_results(results)
            self.status_bar.set_status(f"多条件筛选完成，{len(filtered_df)} 行满足条件")
            
            if messagebox.askyesno("确认", f"找到 {len(filtered_df)} 行数据，是否仅保留这些数据？"):
                self.current_df = filtered_df.reset_index(drop=True)
                
        except Exception as e:
            messagebox.showerror("错误", f"筛选表达式错误: {str(e)}\n\n提示: 列名需要用反引号包围（如 `列名`），字符串值要用引号")
    
    def sort_data(self):
        """排序数据"""
        if not self.check_file_loaded():
            return
        
        column = self.sort_column_var.get()
        if not column or column not in self.current_df.columns:
            messagebox.showwarning("警告", "请选择有效的排序列")
            return
        
        try:
            self.save_state()
            ascending = self.sort_order_var.get() == "ascending"
            self.current_df = self.current_df.sort_values(by=column, ascending=ascending, na_position='last')
            self.current_df.reset_index(drop=True, inplace=True)
            
            order_text = "升序" if ascending else "降序"
            self.status_bar.set_status(f"已按列 '{column}' {order_text}排序")
            
        except Exception as e:
            messagebox.showerror("错误", f"排序失败: {str(e)}")
    
    # ==================== 转换功能方法 ====================
    
    def replace_all(self):
        """执行查找替换"""
        if not self.check_file_loaded():
            return
        
        column = self.replace_column_var.get()
        find_text = self.find_text_var.get()
        replace_text = self.replace_text_var.get()
        use_regex = self.replace_regex_var.get()
        
        if not column:
            messagebox.showwarning("警告", "请选择目标列")
            return
        
        if column not in self.current_df.columns:
            messagebox.showerror("错误", f"列 '{column}' 不存在")
            return
        
        try:
            self.save_state()
            
            original = self.current_df[column].copy()
            
            if use_regex:
                self.current_df[column] = self.current_df[column].astype(str).str.replace(
                    find_text, replace_text, regex=True
                )
            else:
                self.current_df[column] = self.current_df[column].astype(str).str.replace(
                    find_text, replace_text, regex=False
                )
            
            changed_count = (original.astype(str) != self.current_df[column].astype(str)).sum()
            
            messagebox.showinfo("完成", f"替换完成，共修改 {changed_count} 个单元格")
            self.status_bar.set_status(f"替换完成: {changed_count} 处")
            
        except Exception as e:
            messagebox.showerror("错误", f"替换失败: {str(e)}")
    
    def preview_replace(self):
        """预览替换结果"""
        if not self.check_file_loaded():
            return
        
        column = self.replace_column_var.get()
        find_text = self.find_text_var.get()
        replace_text = self.replace_text_var.get()
        use_regex = self.replace_regex_var.get()
        
        if not column or column not in self.current_df.columns:
            messagebox.showwarning("警告", "请选择有效的目标列")
            return
        
        try:
            results = []
            for idx, value in self.current_df[column].items():
                str_value = str(value)
                if use_regex:
                    if re.search(find_text, str_value):
                        new_value = re.sub(find_text, replace_text, str_value)
                        results.append({
                            "行": idx + 2,
                            "列": column,
                            "内容": f"原: {str_value[:40]}",
                            "附加信息": f"新: {new_value[:40]}"
                        })
                else:
                    if find_text in str_value:
                        new_value = str_value.replace(find_text, replace_text)
                        results.append({
                            "行": idx + 2,
                            "列": column,
                            "内容": f"原: {str_value[:40]}",
                            "附加信息": f"新: {new_value[:40]}"
                        })
                
                if len(results) >= 50:
                    break
            
            self.display_results(results)
            self.status_bar.set_status(f"预览: 将修改约 {len(results)}+ 处")
            
        except Exception as e:
            messagebox.showerror("错误", f"预览失败: {str(e)}")
    
    def split_column(self):
        """拆分列"""
        if not self.check_file_loaded():
            return
        
        # 使用对话框获取参数
        column = simpledialog.askstring("拆分列", "请输入要拆分的列名:")
        if not column or column not in self.current_df.columns:
            messagebox.showwarning("警告", "列名无效")
            return
        
        delimiter = simpledialog.askstring("拆分列", "请输入分隔符 (如: , 或 _ ):", initialvalue=",")
        if delimiter is None:
            return
        
        try:
            self.save_state()
            
            # 拆分列
            split_df = self.current_df[column].astype(str).str.split(delimiter, expand=True)
            
            # 为新列命名
            new_columns = [f"{column}_拆分{i+1}" for i in range(split_df.shape[1])]
            split_df.columns = new_columns
            
            # 合并到原数据
            self.current_df = pd.concat([self.current_df, split_df], axis=1)
            self.update_column_combos()
            
            messagebox.showinfo("完成", f"已将列 '{column}' 拆分为 {len(new_columns)} 列")
            self.status_bar.set_status(f"列拆分完成")
            
        except Exception as e:
            messagebox.showerror("错误", f"拆分失败: {str(e)}")
    
    def merge_columns(self):
        """合并列"""
        if not self.check_file_loaded():
            return
        
        columns = simpledialog.askstring("合并列", "请输入要合并的列名 (逗号分隔):")
        if not columns:
            return
        
        col_list = [col.strip() for col in columns.split(',')]
        missing = [col for col in col_list if col not in self.current_df.columns]
        if missing:
            messagebox.showerror("错误", f"以下列不存在: {missing}")
            return
        
        separator = simpledialog.askstring("合并列", "请输入连接符:", initialvalue="_")
        if separator is None:
            separator = ""
        
        new_col_name = simpledialog.askstring("合并列", "请输入新列名:", initialvalue="合并列")
        if not new_col_name:
            return
        
        try:
            self.save_state()
            self.current_df[new_col_name] = self.current_df[col_list].astype(str).agg(separator.join, axis=1)
            self.update_column_combos()
            
            messagebox.showinfo("完成", f"已将 {len(col_list)} 列合并为 '{new_col_name}'")
            self.status_bar.set_status(f"列合并完成")
            
        except Exception as e:
            messagebox.showerror("错误", f"合并失败: {str(e)}")
    
    def rename_column(self):
        """重命名列"""
        if not self.check_file_loaded():
            return
        
        old_name = simpledialog.askstring("重命名列", f"请输入要重命名的列名:\n可用列: {list(self.current_df.columns)[:10]}...")
        if not old_name or old_name not in self.current_df.columns:
            messagebox.showwarning("警告", "列名无效")
            return
        
        new_name = simpledialog.askstring("重命名列", f"请输入 '{old_name}' 的新名称:")
        if not new_name:
            return
        
        try:
            self.save_state()
            self.current_df = self.current_df.rename(columns={old_name: new_name})
            self.update_column_combos()
            
            messagebox.showinfo("完成", f"已将列 '{old_name}' 重命名为 '{new_name}'")
            self.status_bar.set_status(f"列重命名完成")
            
        except Exception as e:
            messagebox.showerror("错误", f"重命名失败: {str(e)}")
    
    def delete_column(self):
        """删除列"""
        if not self.check_file_loaded():
            return
        
        column = simpledialog.askstring("删除列", f"请输入要删除的列名:\n可用列: {list(self.current_df.columns)}")
        if not column or column not in self.current_df.columns:
            messagebox.showwarning("警告", "列名无效")
            return
        
        if messagebox.askyesno("确认", f"确定要删除列 '{column}' 吗？此操作可通过'撤销'恢复。"):
            try:
                self.save_state()
                self.current_df = self.current_df.drop(columns=[column])
                self.update_column_combos()
                
                messagebox.showinfo("完成", f"已删除列 '{column}'")
                self.status_bar.set_status(f"列删除完成")
                
            except Exception as e:
                messagebox.showerror("错误", f"删除失败: {str(e)}")
    
    def add_column(self):
        """新增列"""
        if not self.check_file_loaded():
            return
        
        col_name = simpledialog.askstring("新增列", "请输入新列名:")
        if not col_name:
            return
        
        default_value = simpledialog.askstring("新增列", "请输入默认值 (留空则为空值):", initialvalue="")
        
        try:
            self.save_state()
            self.current_df[col_name] = default_value if default_value else None
            self.update_column_combos()
            
            messagebox.showinfo("完成", f"已添加列 '{col_name}'")
            self.status_bar.set_status(f"列添加完成")
            
        except Exception as e:
            messagebox.showerror("错误", f"添加失败: {str(e)}")
    
    def clean_data(self, clean_type: str):
        """数据清洗"""
        if not self.check_file_loaded():
            return
        
        column = self.clean_column_var.get()
        if not column or column not in self.current_df.columns:
            messagebox.showwarning("警告", "请选择有效的目标列")
            return
        
        try:
            self.save_state()
            
            if clean_type == 'strip':
                self.current_df[column] = self.current_df[column].astype(str).str.strip()
                msg = "已去除空格"
            elif clean_type == 'upper':
                self.current_df[column] = self.current_df[column].astype(str).str.upper()
                msg = "已转换为大写"
            elif clean_type == 'lower':
                self.current_df[column] = self.current_df[column].astype(str).str.lower()
                msg = "已转换为小写"
            else:
                return
            
            self.status_bar.set_status(f"列 '{column}' {msg}")
            
        except Exception as e:
            messagebox.showerror("错误", f"清洗失败: {str(e)}")
    
    def fill_empty_values(self):
        """填充空值"""
        if not self.check_file_loaded():
            return
        
        column = self.clean_column_var.get()
        if not column or column not in self.current_df.columns:
            messagebox.showwarning("警告", "请选择有效的目标列")
            return
        
        fill_value = simpledialog.askstring("填充空值", "请输入要填充的值:")
        if fill_value is None:
            return
        
        try:
            self.save_state()
            empty_count = self.current_df[column].isnull().sum()
            self.current_df[column] = self.current_df[column].fillna(fill_value)
            
            messagebox.showinfo("完成", f"已将列 '{column}' 中的 {empty_count} 个空值填充为 '{fill_value}'")
            self.status_bar.set_status(f"空值填充完成")
            
        except Exception as e:
            messagebox.showerror("错误", f"填充失败: {str(e)}")
    
    # ==================== 合并功能方法 ====================
    
    def browse_vlookup_file(self):
        """浏览VLOOKUP匹配文件"""
        file_path = filedialog.askopenfilename(
            title="选择匹配文件",
            filetypes=[("Excel Files", "*.xlsx *.xls"), ("CSV Files", "*.csv"), ("All Files", "*.*")]
        )
        if file_path:
            self.vlookup_file_var.set(file_path)
    
    def perform_vlookup(self):
        """执行VLOOKUP匹配"""
        if not self.check_file_loaded():
            return
        
        key_col = self.vlookup_key_var.get().strip()
        lookup_file = self.vlookup_file_var.get().strip()
        match_col = self.vlookup_match_var.get().strip()
        return_col = self.vlookup_return_var.get().strip()
        
        if not all([key_col, lookup_file, match_col, return_col]):
            messagebox.showwarning("警告", "请填写完整的VLOOKUP参数")
            return
        
        if key_col not in self.current_df.columns:
            messagebox.showerror("错误", f"查找值列 '{key_col}' 不存在")
            return
        
        try:
            # 加载匹配文件
            if lookup_file.endswith('.csv'):
                lookup_df = pd.read_csv(lookup_file, encoding='utf-8-sig')
            else:
                lookup_df = pd.read_excel(lookup_file)
            
            if match_col not in lookup_df.columns or return_col not in lookup_df.columns:
                messagebox.showerror("错误", f"匹配文件中不存在指定的列")
                return
            
            self.save_state()
            
            # 创建匹配字典
            lookup_dict = dict(zip(lookup_df[match_col].astype(str), lookup_df[return_col]))
            
            # 执行匹配
            new_col_name = f"{return_col}_匹配结果"
            self.current_df[new_col_name] = self.current_df[key_col].astype(str).map(lookup_dict)
            
            matched_count = self.current_df[new_col_name].notna().sum()
            self.update_column_combos()
            
            messagebox.showinfo("完成", f"VLOOKUP完成\n匹配成功: {matched_count} 行\n未匹配: {len(self.current_df) - matched_count} 行")
            self.status_bar.set_status(f"VLOOKUP完成，匹配 {matched_count} 行")
            
        except Exception as e:
            messagebox.showerror("错误", f"VLOOKUP失败: {str(e)}")
    
    def select_merge_files(self):
        """选择要合并的文件"""
        files = filedialog.askopenfilenames(
            title="选择要合并的文件",
            filetypes=[("Excel Files", "*.xlsx *.xls"), ("CSV Files", "*.csv"), ("All Files", "*.*")]
        )
        
        if files:
            self.merge_files_list = list(files)
            self.merge_files_label.config(text=f"已选择 {len(files)} 个文件", foreground="black")
    
    def merge_files(self):
        """合并多个文件"""
        if not self.merge_files_list:
            messagebox.showwarning("警告", "请先选择要合并的文件")
            return
        
        try:
            dfs = []
            for file_path in self.merge_files_list:
                if file_path.endswith('.csv'):
                    df = pd.read_csv(file_path, encoding='utf-8-sig')
                else:
                    df = pd.read_excel(file_path)
                dfs.append(df)
            
            merge_type = self.merge_type_var.get()
            
            if merge_type == "vertical":
                merged_df = pd.concat(dfs, axis=0, ignore_index=True)
            else:
                merged_df = pd.concat(dfs, axis=1)
            
            # 保存当前数据
            if self.current_df is not None:
                self.save_state()
            
            self.current_df = merged_df
            self.original_df = merged_df.copy()
            self.update_column_combos()
            
            messagebox.showinfo("完成", f"已合并 {len(dfs)} 个文件\n总行数: {len(merged_df)}, 总列数: {len(merged_df.columns)}")
            self.status_bar.set_status(f"文件合并完成")
            
        except Exception as e:
            messagebox.showerror("错误", f"合并失败: {str(e)}")
    
    def group_and_aggregate(self):
        """分组汇总"""
        if not self.check_file_loaded():
            return
        
        group_col = self.group_column_var.get().strip()
        agg_col = self.agg_column_var.get().strip()
        agg_func = self.agg_func_var.get()
        
        if not group_col or not agg_col:
            messagebox.showwarning("警告", "请填写分组列和汇总列")
            return
        
        # 支持多列分组
        group_cols = [col.strip() for col in group_col.split(',')]
        missing = [col for col in group_cols if col not in self.current_df.columns]
        if missing:
            messagebox.showerror("错误", f"以下分组列不存在: {missing}")
            return
        
        if agg_col not in self.current_df.columns:
            messagebox.showerror("错误", f"汇总列 '{agg_col}' 不存在")
            return
        
        try:
            # 转换为数值
            self.current_df[agg_col] = pd.to_numeric(self.current_df[agg_col], errors='coerce')
            
            # 执行分组汇总
            if agg_func == 'sum':
                result = self.current_df.groupby(group_cols)[agg_col].sum()
            elif agg_func == 'mean':
                result = self.current_df.groupby(group_cols)[agg_col].mean()
            elif agg_func == 'count':
                result = self.current_df.groupby(group_cols)[agg_col].count()
            elif agg_func == 'max':
                result = self.current_df.groupby(group_cols)[agg_col].max()
            elif agg_func == 'min':
                result = self.current_df.groupby(group_cols)[agg_col].min()
            elif agg_func == 'std':
                result = self.current_df.groupby(group_cols)[agg_col].std()
            else:
                result = self.current_df.groupby(group_cols)[agg_col].sum()
            
            # 转换为DataFrame
            result_df = result.reset_index()
            result_df.columns = list(result_df.columns[:-1]) + [f"{agg_col}_{agg_func}"]
            
            # 显示结果
            results = []
            for idx, row in result_df.iterrows():
                results.append({
                    "行": idx + 1,
                    "列": str(dict(row[group_cols])),
                    "内容": f"{agg_col}_{agg_func}",
                    "附加信息": f"{row.iloc[-1]:.4f}" if isinstance(row.iloc[-1], float) else str(row.iloc[-1])
                })
            
            self.display_results(results)
            self.status_bar.set_status(f"分组汇总完成，共 {len(result_df)} 组")
            
            # 询问是否替换当前数据
            if messagebox.askyesno("确认", "是否用汇总结果替换当前数据？"):
                self.save_state()
                self.current_df = result_df
                self.update_column_combos()
            
        except Exception as e:
            messagebox.showerror("错误", f"分组汇总失败: {str(e)}")
    
    # ==================== 通用方法 ====================
    
    def check_file_loaded(self):
        """检查文件是否已加载"""
        if self.current_df is None:
            messagebox.showwarning("警告", "请先选择并加载一个Excel文件")
            return False
        return True
    
    def display_results(self, results: List[Dict]):
        """显示结果"""
        self.clear_results()
        self.search_results = results
        for r in results:
            self.results_tree.insert("", tk.END, values=(
                r.get("行", ""),
                r.get("列", ""),
                r.get("内容", ""),
                r.get("附加信息", "")
            ))
    
    def clear_results(self):
        """清除结果"""
        for item in self.results_tree.get_children():
            self.results_tree.delete(item)
        self.search_results = None
    
    def sort_results_by_column(self, column):
        """按列排序结果"""
        if not self.search_results:
            return
        
        col_map = {"行": "行", "列": "列", "内容": "内容", "附加信息": "附加信息"}
        key = col_map.get(column)
        if key:
            try:
                # 尝试数值排序
                self.search_results.sort(key=lambda x: float(x.get(key, 0)) if str(x.get(key, '')).replace('.', '').isdigit() else 0)
            except:
                # 字符串排序
                self.search_results.sort(key=lambda x: str(x.get(key, '')))
            
            self.display_results(self.search_results)
    
    def export_results(self):
        """导出结果"""
        if not self.search_results:
            messagebox.showwarning("警告", "当前没有可导出的结果")
            return
        
        try:
            file_path = filedialog.asksaveasfilename(
                defaultextension=".xlsx",
                filetypes=[("Excel Files", "*.xlsx"), ("CSV Files", "*.csv")],
                title="导出结果"
            )
            
            if file_path:
                df_results = pd.DataFrame(self.search_results)
                if file_path.endswith('.csv'):
                    df_results.to_csv(file_path, index=False, encoding='utf-8-sig')
                else:
                    df_results.to_excel(file_path, index=False)
                
                messagebox.showinfo("成功", f"结果已导出到: {file_path}")
                self.status_bar.set_status(f"结果已导出")
                
        except Exception as e:
            messagebox.showerror("错误", f"导出失败: {str(e)}")
    
    def preview_data(self):
        """预览数据"""
        if not self.check_file_loaded():
            return
        
        try:
            preview_rows = min(20, len(self.current_df))
            results = []
            for idx, row in self.current_df.head(preview_rows).iterrows():
                row_dict = row.to_dict()
                # 截断过长的内容
                content = str({k: (str(v)[:20] + '...' if len(str(v)) > 20 else v) for k, v in list(row_dict.items())[:5]})
                results.append({
                    "行": idx + 2,
                    "列": "预览",
                    "内容": content,
                    "附加信息": f"共 {len(row_dict)} 列"
                })
            
            self.display_results(results)
            self.status_bar.set_status(f"数据预览: 显示前 {preview_rows} 行")
            
        except Exception as e:
            messagebox.showerror("错误", f"预览失败: {str(e)}")
    
    def on_tab_focus(self):
        """标签页获得焦点时"""
        self.status_bar.set_status("Excel工具模块已激活")
    
    def setup_visualization_tab(self):
        """设置数据可视化功能标签页"""
        viz_frame = ttk.Frame(self.function_notebook)
        self.function_notebook.add(viz_frame, text="📈 数据可视化")

        # 图表类型选择
        type_frame = ttk.LabelFrame(viz_frame, text="图表类型", padding="5")
        type_frame.pack(fill=tk.X, pady=5, padx=5)

        row1 = ttk.Frame(type_frame)
        row1.pack(fill=tk.X, pady=2)

        self.chart_type_var = tk.StringVar(value="柱状图")
        chart_types = ["柱状图", "折线图", "饼图", "散点图", "面积图", "直方图", "箱线图", "热力图"]

        for i, chart_type in enumerate(chart_types):
            if i % 4 == 0 and i > 0:
                row1 = ttk.Frame(type_frame)
                row1.pack(fill=tk.X, pady=2)
            ttk.Radiobutton(row1, text=chart_type, variable=self.chart_type_var,
                          value=chart_type).pack(side=tk.LEFT, padx=5)

        # 数据选择
        data_frame = ttk.LabelFrame(viz_frame, text="数据选择", padding="5")
        data_frame.pack(fill=tk.X, pady=5, padx=5)

        row2 = ttk.Frame(data_frame)
        row2.pack(fill=tk.X, pady=2)
        ttk.Label(row2, text="X轴/分类列:").pack(side=tk.LEFT, padx=(0, 5))
        self.viz_x_var = tk.StringVar()
        self.viz_x_combo = ttk.Combobox(row2, textvariable=self.viz_x_var, width=20)
        self.viz_x_combo.pack(side=tk.LEFT, padx=(0, 10))

        ttk.Label(row2, text="Y轴/数值列:").pack(side=tk.LEFT, padx=(0, 5))
        self.viz_y_var = tk.StringVar()
        self.viz_y_combo = ttk.Combobox(row2, textvariable=self.viz_y_var, width=20)
        self.viz_y_combo.pack(side=tk.LEFT, padx=(0, 10))

        ttk.Button(row2, text="刷新列", command=self.update_viz_columns).pack(side=tk.LEFT, padx=5)

        # 图表设置
        settings_frame = ttk.LabelFrame(viz_frame, text="图表设置", padding="5")
        settings_frame.pack(fill=tk.X, pady=5, padx=5)

        row3 = ttk.Frame(settings_frame)
        row3.pack(fill=tk.X, pady=2)
        ttk.Label(row3, text="图表标题:").pack(side=tk.LEFT, padx=(0, 5))
        self.chart_title_var = tk.StringVar(value="数据图表")
        ttk.Entry(row3, textvariable=self.chart_title_var, width=30).pack(side=tk.LEFT, padx=(0, 10))

        ttk.Label(row3, text="X轴标签:").pack(side=tk.LEFT, padx=(0, 5))
        self.x_label_var = tk.StringVar()
        ttk.Entry(row3, textvariable=self.x_label_var, width=15).pack(side=tk.LEFT, padx=(0, 10))

        ttk.Label(row3, text="Y轴标签:").pack(side=tk.LEFT, padx=(0, 5))
        self.y_label_var = tk.StringVar()
        ttk.Entry(row3, textvariable=self.y_label_var, width=15).pack(side=tk.LEFT)

        row4 = ttk.Frame(settings_frame)
        row4.pack(fill=tk.X, pady=2)

        self.show_legend_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(row4, text="显示图例", variable=self.show_legend_var).pack(side=tk.LEFT, padx=5)

        self.show_grid_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(row4, text="显示网格", variable=self.show_grid_var).pack(side=tk.LEFT, padx=5)

        self.show_values_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(row4, text="显示数值", variable=self.show_values_var).pack(side=tk.LEFT, padx=5)

        self.absolute_value_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(row4, text="取绝对值", variable=self.absolute_value_var).pack(side=tk.LEFT, padx=5)

        ttk.Label(row4, text="颜色方案:").pack(side=tk.LEFT, padx=(10, 5))
        self.color_scheme_var = tk.StringVar(value="default")
        ttk.Combobox(row4, textvariable=self.color_scheme_var,
                     values=["default", "blues", "greens", "reds", "viridis", "plasma"],
                     width=10).pack(side=tk.LEFT)

        # 操作按钮
        button_frame = ttk.Frame(viz_frame)
        button_frame.pack(fill=tk.X, pady=10, padx=5)

        ttk.Button(button_frame, text="生成图表", command=self.generate_chart).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="保存图表", command=self.save_chart).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="清除图表", command=self.clear_chart).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="快速分析", command=self.quick_analysis).pack(side=tk.RIGHT, padx=5)

        # 图表显示区域
        self.chart_frame = ttk.LabelFrame(viz_frame, text="图表预览", padding="5")
        self.chart_frame.pack(fill=tk.BOTH, expand=True, pady=5, padx=5)

        # 添加matplotlib支持
        try:
            import matplotlib.pyplot as plt
            from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2Tk
            import matplotlib.dates as mdates
            from matplotlib import rcParams

            # 设置中文字体
            rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei', 'Arial Unicode MS']
            rcParams['axes.unicode_minus'] = False

            self.matplotlib_available = True
            self.fig = None
            self.canvas = None

        except ImportError:
            self.matplotlib_available = False
            # 显示提示信息
            no_viz_label = ttk.Label(self.chart_frame,
                                   text="数据可视化功能需要安装matplotlib库\n\n请使用以下命令安装:\npip install matplotlib",
                                   justify=tk.CENTER)
            no_viz_label.pack(expand=True)

    def update_viz_columns(self):
        """更新可视化列选择下拉框"""
        if not self.check_file_loaded():
            return

        if self.current_df is not None:
            columns = [str(col) for col in self.current_df.columns]
            if hasattr(self, 'viz_x_combo') and hasattr(self, 'viz_y_combo'):
                self.viz_x_combo['values'] = columns
                self.viz_y_combo['values'] = columns

                # 默认选择
                if len(columns) > 0:
                    self.viz_x_var.set(columns[0])
                if len(columns) > 1:
                    self.viz_y_var.set(columns[1])
                elif len(columns) > 0:
                    self.viz_y_var.set(columns[0])

    def generate_chart(self):
        """生成图表"""
        if not self.check_file_loaded():
            return

        if not self.matplotlib_available:
            messagebox.showerror("错误", "matplotlib库未安装，无法使用数据可视化功能")
            return

        chart_type = self.chart_type_var.get()
        x_col = self.viz_x_var.get()
        y_col = self.viz_y_var.get()

        if not x_col or not y_col:
            messagebox.showwarning("警告", "请选择X轴和Y轴数据列")
            return

        if x_col not in self.current_df.columns or y_col not in self.current_df.columns:
            messagebox.showerror("错误", "选择的列不存在")
            return

        try:
            # 清除之前的图表
            self.clear_chart()

            # 创建新的图形
            import matplotlib.pyplot as plt
            self.fig, self.ax = plt.subplots(figsize=(10, 6))

            # 获取数据
            x_data = self.current_df[x_col]
            y_data = pd.to_numeric(self.current_df[y_col], errors='coerce')

            # 检查负数并处理绝对值
            has_negative = False
            absolute_suffix = ""
            if self.absolute_value_var.get() and chart_type not in ["饼图", "热力图"]:
                negative_count = (y_data < 0).sum()
                if negative_count > 0:
                    has_negative = True
                    y_data = y_data.abs()
                    absolute_suffix = " (已取绝对值)"
                    messagebox.showinfo("提示", f"检测到 {negative_count} 个负值，已自动取绝对值显示")

            # 更新图表标题
            title = self.chart_title_var.get() + absolute_suffix

            # 根据图表类型绘制
            if chart_type == "柱状图":
                self.create_bar_chart(x_data, y_data)
            elif chart_type == "折线图":
                self.create_line_chart(x_data, y_data)
            elif chart_type == "饼图":
                self.create_pie_chart(x_data, y_data)
            elif chart_type == "散点图":
                self.create_scatter_plot(x_data, y_data)
            elif chart_type == "面积图":
                self.create_area_chart(x_data, y_data)
            elif chart_type == "直方图":
                self.create_histogram(y_data)
            elif chart_type == "箱线图":
                self.create_box_plot(x_data, y_data)
            elif chart_type == "热力图":
                self.create_heatmap()

            # 设置图表标题和标签
            self.ax.set_title(title, fontsize=14, fontweight='bold')
            if chart_type not in ["饼图", "热力图"]:
                self.ax.set_xlabel(self.x_label_var.get() or x_col)
                y_label = self.y_label_var.get() or y_col
                if absolute_suffix and "绝对值" not in y_label:
                    y_label += absolute_suffix
                self.ax.set_ylabel(y_label)

            # 显示网格和图例
            if self.show_grid_var.get() and chart_type not in ["饼图"]:
                self.ax.grid(True, alpha=0.3)

            # 添加零参考线（对非饼图、非热力图有效）
            if chart_type in ["柱状图", "折线图", "散点图", "面积图"] and has_negative:
                self.ax.axhline(y=0, color='red', linestyle='--', alpha=0.5, linewidth=1)

            if self.show_legend_var.get() and chart_type in ["柱状图", "折线图", "面积图", "散点图"]:
                self.ax.legend()

            # 调整布局
            plt.tight_layout()

            # 嵌入到Tkinter
            from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
            self.canvas = FigureCanvasTkAgg(self.fig, master=self.chart_frame)
            self.canvas.draw()
            self.canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)

            # 添加工具栏
            from matplotlib.backends.backend_tkagg import NavigationToolbar2Tk
            toolbar = NavigationToolbar2Tk(self.canvas, self.chart_frame)
            toolbar.update()

            self.status_bar.set_status(f"图表生成成功: {chart_type}{absolute_suffix}")

        except Exception as e:
            messagebox.showerror("错误", f"生成图表失败: {str(e)}")
            if self.fig:
                plt.close(self.fig)

    def create_bar_chart(self, x_data, y_data):
        """创建柱状图"""
        # 处理数据聚合
        if pd.api.types.is_numeric_dtype(x_data):
            # 如果X轴是数值，创建分组统计
            df_temp = pd.DataFrame({'x': x_data, 'y': y_data}).dropna()
            df_grouped = df_temp.groupby('x')['y'].sum()
            x_vals = df_grouped.index
            y_vals = df_grouped.values
        else:
            # X轴是分类，直接使用
            df_temp = pd.DataFrame({'x': x_data, 'y': y_data}).dropna()
            df_grouped = df_temp.groupby('x')['y'].sum()
            x_vals = df_grouped.index
            y_vals = df_grouped.values

        # 应用颜色方案
        color = self.get_color_scheme(len(y_vals))

        # 绘制柱状图
        bars = self.ax.bar(range(len(x_vals)), y_vals, color=color)

        # 设置X轴标签
        self.ax.set_xticks(range(len(x_vals)))
        self.ax.set_xticklabels([str(x)[:10] for x in x_vals], rotation=45, ha='right')

        # 显示数值
        if self.show_values_var.get():
            for bar in bars:
                height = bar.get_height()
                self.ax.text(bar.get_x() + bar.get_width()/2., height,
                           f'{height:.1f}', ha='center', va='bottom')

    def create_line_chart(self, x_data, y_data):
        """创建折线图"""
        # 处理数据
        df_temp = pd.DataFrame({'x': x_data, 'y': y_data}).dropna().sort_values('x')

        # 绘制折线图
        color = self.get_color_scheme(1)[0]
        self.ax.plot(df_temp['x'], df_temp['y'], marker='o', color=color, linewidth=2)

        # 处理X轴标签
        if pd.api.types.is_numeric_dtype(df_temp['x']):
            pass  # 数值轴
        else:
            # 旋转文本标签
            self.ax.tick_params(axis='x', rotation=45)

    def create_pie_chart(self, x_data, y_data):
        """创建饼图"""
        # 数据聚合
        df_temp = pd.DataFrame({'x': x_data, 'y': y_data}).dropna()
        df_grouped = df_temp.groupby('x')['y'].sum()

        # 获取前N个数据，其他合并为"其他"
        max_slices = 10
        if len(df_grouped) > max_slices:
            top_data = df_grouped.nlargest(max_slices-1)
            other_sum = df_grouped.iloc[max_slices-1:].sum()
            df_grouped = pd.concat([top_data, pd.Series({'其他': other_sum})])

        # 应用颜色方案
        colors = self.get_color_scheme(len(df_grouped))

        # 绘制饼图
        wedges, texts, autotexts = self.ax.pie(df_grouped.values,
                                              labels=df_grouped.index,
                                              colors=colors,
                                              autopct='%1.1f%%',
                                              startangle=90)

        # 确保文本可读
        for autotext in autotexts:
            autotext.set_color('white')

    def create_scatter_plot(self, x_data, y_data):
        """创建散点图"""
        df_temp = pd.DataFrame({'x': x_data, 'y': y_data}).dropna()

        # 转换X轴为数值（如果可能）
        x_numeric = pd.to_numeric(df_temp['x'], errors='coerce')
        if x_numeric.isnull().all():
            # 如果无法转换，使用类别编码
            x_numeric = df_temp['x'].astype('category').cat.codes

        color = self.get_color_scheme(1)[0]
        scatter = self.ax.scatter(x_numeric, df_temp['y'],
                                color=color, alpha=0.6, s=50)

        # 设置X轴标签
        if not pd.api.types.is_numeric_dtype(x_data):
            self.ax.set_xticks(range(len(df_temp['x'].unique())))
            self.ax.set_xticklabels(df_temp['x'].unique()[:10], rotation=45)

    def create_area_chart(self, x_data, y_data):
        """创建面积图"""
        df_temp = pd.DataFrame({'x': x_data, 'y': y_data}).dropna().sort_values('x')

        color = self.get_color_scheme(1)[0]
        self.ax.fill_between(df_temp.index, 0, df_temp['y'],
                            color=color, alpha=0.3)
        self.ax.plot(df_temp.index, df_temp['y'], color=color, linewidth=2)

        # 设置X轴
        self.ax.set_xticks(range(len(df_temp)))
        if len(df_temp) <= 20:
            self.ax.set_xticklabels([str(x)[:10] for x in df_temp['x']], rotation=45)
        else:
            # 如果数据点太多，只显示部分标签
            step = len(df_temp) // 10
            labels = [str(df_temp['x'].iloc[i])[:10] if i < len(df_temp) else ''
                     for i in range(0, len(df_temp), step)]
            self.ax.set_xticks(range(0, len(df_temp), step))
            self.ax.set_xticklabels(labels, rotation=45)

    def create_histogram(self, y_data):
        """创建直方图"""
        data = y_data.dropna()

        # 自动确定bins数量
        n_bins = min(30, int(np.sqrt(len(data))))

        color = self.get_color_scheme(1)[0]
        n, bins, patches = self.ax.hist(data, bins=n_bins, color=color, alpha=0.7, edgecolor='black')

        # 添加统计线
        mean_val = data.mean()
        std_val = data.std()
        self.ax.axvline(mean_val, color='red', linestyle='--', linewidth=2, label=f'均值: {mean_val:.2f}')
        self.ax.axvline(mean_val + std_val, color='orange', linestyle='--', alpha=0.7, label=f'+1σ: {mean_val + std_val:.2f}')
        self.ax.axvline(mean_val - std_val, color='orange', linestyle='--', alpha=0.7, label=f'-1σ: {mean_val - std_val:.2f}')

        if self.show_legend_var.get():
            self.ax.legend()

    def create_box_plot(self, x_data, y_data):
        """创建箱线图"""
        df_temp = pd.DataFrame({'x': x_data, 'y': y_data}).dropna()

        # 按X轴分组
        groups = df_temp.groupby('x')['y'].apply(list)

        # 准备数据
        data = [g for g in groups.values if len(g) > 0]
        labels = [str(k)[:10] for k in groups.keys()]

        # 绘制箱线图
        box_plot = self.ax.boxplot(data, labels=labels, patch_artist=True)

        # 应用颜色
        colors = self.get_color_scheme(len(data))
        for patch, color in zip(box_plot['boxes'], colors):
            patch.set_facecolor(color)
            patch.set_alpha(0.7)

        # 旋转X轴标签
        self.ax.tick_params(axis='x', rotation=45)

    def create_heatmap(self):
        """创建热力图（数值列的相关性）"""
        # 选择数值列
        numeric_cols = self.current_df.select_dtypes(include=[np.number]).columns

        if len(numeric_cols) < 2:
            messagebox.showwarning("警告", "需要至少两个数值列才能创建热力图")
            return

        # 计算相关性矩阵
        corr_matrix = self.current_df[numeric_cols].corr()

        # 创建热力图
        import matplotlib.pyplot as plt
        im = self.ax.imshow(corr_matrix.values, cmap='coolwarm', aspect='auto', vmin=-1, vmax=1)

        # 设置刻度和标签
        self.ax.set_xticks(range(len(numeric_cols)))
        self.ax.set_yticks(range(len(numeric_cols)))
        self.ax.set_xticklabels([str(col)[:10] for col in numeric_cols], rotation=45)
        self.ax.set_yticklabels([str(col)[:10] for col in numeric_cols])

        # 添加数值文本
        for i in range(len(numeric_cols)):
            for j in range(len(numeric_cols)):
                text = self.ax.text(j, i, f'{corr_matrix.iloc[i, j]:.2f}',
                                  ha="center", va="center", color="black")

        # 添加颜色条
        cbar = self.fig.colorbar(im, ax=self.ax)
        cbar.set_label('相关系数')

        self.ax.set_title("数值特征相关性热力图")

    def get_color_scheme(self, n):
        """获取颜色方案"""
        import matplotlib.pyplot as plt

        scheme = self.color_scheme_var.get()

        if scheme == "default":
            return plt.cm.tab20(np.linspace(0, 1, n))
        elif scheme == "blues":
            return plt.cm.Blues(np.linspace(0.4, 1, n))
        elif scheme == "greens":
            return plt.cm.Greens(np.linspace(0.4, 1, n))
        elif scheme == "reds":
            return plt.cm.Reds(np.linspace(0.4, 1, n))
        elif scheme == "viridis":
            return plt.cm.viridis(np.linspace(0, 1, n))
        elif scheme == "plasma":
            return plt.cm.plasma(np.linspace(0, 1, n))
        else:
            return plt.cm.tab20(np.linspace(0, 1, n))

    def save_chart(self):
        """保存图表"""
        if not self.matplotlib_available or not self.fig:
            messagebox.showwarning("警告", "没有可保存的图表")
            return

        try:
            file_path = filedialog.asksaveasfilename(
                defaultextension=".png",
                filetypes=[("PNG Files", "*.png"), ("PDF Files", "*.pdf"),
                          ("SVG Files", "*.svg"), ("All Files", "*.*")],
                title="保存图表"
            )

            if file_path:
                self.fig.savefig(file_path, dpi=300, bbox_inches='tight')
                messagebox.showinfo("成功", f"图表已保存到: {file_path}")
                self.status_bar.set_status("图表已保存")

        except Exception as e:
            messagebox.showerror("错误", f"保存图表失败: {str(e)}")

    def clear_chart(self):
        """清除图表"""
        # 清除画布
        for widget in self.chart_frame.winfo_children():
            if isinstance(widget, (tk.Frame, tk.Canvas)):
                widget.destroy()

        # 重置变量
        self.fig = None
        self.canvas = None

    def quick_analysis(self):
        """快速数据分析并生成合适的图表"""
        if not self.check_file_loaded():
            return

        try:
            # 自动选择适合的图表类型
            numeric_cols = self.current_df.select_dtypes(include=[np.number]).columns
            categorical_cols = self.current_df.select_dtypes(include=['object']).columns

            # 默认设置
            self.chart_title_var.set("数据快速分析")

            if len(numeric_cols) >= 2:
                # 有多个数值列，创建相关性热力图
                self.chart_type_var.set("热力图")
                self.generate_chart()
            elif len(numeric_cols) >= 1 and len(categorical_cols) >= 1:
                # 有数值列和分类列，创建柱状图
                self.chart_type_var.set("柱状图")
                self.viz_x_var.set(categorical_cols[0])
                self.viz_y_var.set(numeric_cols[0])
                self.generate_chart()
            elif len(numeric_cols) >= 1:
                # 只有数值列，创建直方图
                self.chart_type_var.set("直方图")
                self.viz_y_var.set(numeric_cols[0])
                self.generate_chart()
            else:
                messagebox.showinfo("提示", "数据类型不适合快速分析，请手动选择图表类型")

        except Exception as e:
            messagebox.showerror("错误", f"快速分析失败: {str(e)}")

    def cleanup(self):
        """清理资源"""
        self.current_df = None
        self.original_df = None
        self.history_stack.clear()
        if self.fig:
            import matplotlib.pyplot as plt
            plt.close(self.fig)


# ==================== 测试代码 ====================
if __name__ == "__main__":
    class MockStatusBar:
        def set_status(self, msg):
            print(f"[状态] {msg}")
    
    root = tk.Tk()
    root.title("Excel工具测试")
    root.geometry("1200x800")
    
    notebook = ttk.Notebook(root)
    notebook.pack(fill=tk.BOTH, expand=True)
    
    status_bar = MockStatusBar()
    excel_module = ExcelSearchModule(notebook, status_bar)
    
    root.mainloop()
