﻿# -*- coding: utf-8 -*-
"""
JSON转换模块
"""

import tkinter as tk
from tkinter import ttk, filedialog, messagebox, scrolledtext
import json
import pandas as pd
from utils.file_utils import FileUtils

class JSONConverterModule:
    """JSON转换功能模块"""
    
    def __init__(self, notebook, status_bar):
        self.notebook = notebook
        self.status_bar = status_bar
        
        # 创建标签页
        self.tab_frame = ttk.Frame(notebook)
        notebook.add(self.tab_frame, text="JSON转换")
        
        self.setup_ui()
        self.current_file = None
        self.current_data = None  # 存储解析后的数据
    
    def setup_ui(self):
        """设置用户界面"""
        # 主容器
        main_frame = ttk.Frame(self.tab_frame, padding="10")
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        # 输入区域
        input_frame = ttk.LabelFrame(main_frame, text="JSON输入", padding="5")
        input_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 10))
        
        # 输入选项
        options_frame = ttk.Frame(input_frame)
        options_frame.pack(fill=tk.X, pady=(0, 5))
        
        ttk.Button(options_frame, text="加载文件", command=self.load_json_file).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Button(options_frame, text="清空", command=self.clear_input).pack(side=tk.LEFT)
        ttk.Button(options_frame, text="转换", command=self.convert_json).pack(side=tk.RIGHT)
        
        # JSON输入文本框
        self.json_text = scrolledtext.ScrolledText(input_frame, height=10, wrap=tk.WORD)
        self.json_text.pack(fill=tk.BOTH, expand=True)
        
        # 转换选项
        convert_frame = ttk.LabelFrame(main_frame, text="转换选项", padding="5")
        convert_frame.pack(fill=tk.X, pady=(0, 10))
        
        self.flatten_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(convert_frame, text="扁平化JSON结构", variable=self.flatten_var).pack(anchor=tk.W)
        
        self.auto_type_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(convert_frame, text="自动检测数据类型", variable=self.auto_type_var).pack(anchor=tk.W)
        
        # 输出格式选择
        output_frame = ttk.Frame(convert_frame)
        output_frame.pack(fill=tk.X, pady=5)
        
        ttk.Label(output_frame, text="输出格式:").pack(side=tk.LEFT, padx=(0, 5))
        self.output_format_var = tk.StringVar(value="Excel")
        ttk.Radiobutton(output_frame, text="Excel", variable=self.output_format_var, value="Excel").pack(side=tk.LEFT, padx=5)
        ttk.Radiobutton(output_frame, text="CSV", variable=self.output_format_var, value="CSV").pack(side=tk.LEFT, padx=5)
        ttk.Radiobutton(output_frame, text="JSON", variable=self.output_format_var, value="JSON").pack(side=tk.LEFT, padx=5)
        
        # 预览区域
        preview_frame = ttk.LabelFrame(main_frame, text="预览", padding="5")
        preview_frame.pack(fill=tk.BOTH, expand=True)
        
        # 预览文本框
        self.preview_text = scrolledtext.ScrolledText(preview_frame, height=8, wrap=tk.WORD)
        self.preview_text.pack(fill=tk.BOTH, expand=True)
        
        # 保存按钮
        save_frame = ttk.Frame(preview_frame)
        save_frame.pack(fill=tk.X, pady=5)
        
        ttk.Button(save_frame, text="保存结果", command=self.save_result).pack(side=tk.RIGHT)
    
    def load_json_file(self):
        """加载JSON文件"""
        file_path = filedialog.askopenfilename(
            title="选择JSON文件",
            filetypes=[("JSON Files", "*.json"), ("All Files", "*.*")]
        )
        
        if file_path:
            try:
                success, data, msg = FileUtils.load_json(file_path)
                if success:
                    json_str = json.dumps(data, ensure_ascii=False, indent=2)
                    self.json_text.delete(1.0, tk.END)
                    self.json_text.insert(1.0, json_str)
                    self.current_file = file_path
                    self.status_bar.set_status(f"已加载文件: {file_path}")
                else:
                    messagebox.showerror("错误", msg)
            except Exception as e:
                messagebox.showerror("错误", f"加载文件失败: {str(e)}")
    
    def clear_input(self):
        """清空输入"""
        self.json_text.delete(1.0, tk.END)
        self.preview_text.delete(1.0, tk.END)
        self.current_file = None
        self.current_data = None
        self.status_bar.set_status("已清空输入")
    
    def convert_json(self):
        """转换JSON"""
        json_content = self.json_text.get(1.0, tk.END).strip()
        
        if not json_content:
            messagebox.showwarning("警告", "请输入JSON内容")
            return
        
        try:
            self.status_bar.set_status("正在转换...", show_progress=True)
            self.status_bar.update_progress(25)
            
            # 解析JSON
            json_data = json.loads(json_content)
            self.current_data = json_data  # 保存原始数据
            self.status_bar.update_progress(50)
            
            # 处理JSON数据
            if self.flatten_var.get():
                processed_data = self.flatten_json(json_data)
            else:
                processed_data = json_data
            
            self.status_bar.update_progress(75)
            
            # 根据输出格式转换数据
            output_format = self.output_format_var.get()
            if output_format == "Excel":
                result_df = self.convert_to_excel(processed_data)
                # 显示DataFrame的预览
                preview_str = "DataFrame 预览:\n"
                preview_str += str(result_df.head(10))
                if len(result_df) > 10:
                    preview_str += f"\n\n... (共 {len(result_df)} 行)"
            elif output_format == "CSV":
                result_df = self.convert_to_excel(processed_data)
                result = result_df.to_csv(index=False, encoding="utf-8-sig")
                preview_str = result[:1000]
                if len(result) > 1000:
                    preview_str += "\n\n... (内容已截断)"
            else:  # JSON
                result = json.dumps(processed_data, ensure_ascii=False, indent=2)
                preview_str = result[:1000]
                if len(result) > 1000:
                    preview_str += "\n\n... (内容已截断)"
            
            # 显示预览
            self.preview_text.delete(1.0, tk.END)
            self.preview_text.insert(1.0, preview_str)
            
            self.status_bar.update_progress(100)
            self.status_bar.set_status("转换完成")
            
        except json.JSONDecodeError as e:
            messagebox.showerror("JSON错误", f"JSON格式错误: {str(e)}")
            self.status_bar.set_status("JSON格式错误")
        except Exception as e:
            messagebox.showerror("错误", f"转换失败: {str(e)}")
            self.status_bar.set_status("转换失败")
    
    def flatten_json(self, json_data, parent_key="", sep="_"):
        """扁平化JSON结构"""
        items = []
        
        if isinstance(json_data, dict):
            for k, v in json_data.items():
                new_key = f"{parent_key}{sep}{k}" if parent_key else k
                items.extend(self.flatten_json(v, new_key, sep).items())
        elif isinstance(json_data, list):
            for i, v in enumerate(json_data):
                new_key = f"{parent_key}{sep}{i}" if parent_key else str(i)
                items.extend(self.flatten_json(v, new_key, sep).items())
        else:
            items.append((parent_key, json_data))
        
        return dict(items)
    
    def convert_to_excel(self, data):
        """转换为Excel DataFrame"""
        if isinstance(data, dict):
            # 如果是字典，转换为键值对
            df = pd.DataFrame(list(data.items()), columns=["键", "值"])
        elif isinstance(data, list):
            if data and isinstance(data[0], dict):
                # 如果是字典列表，直接转换为DataFrame
                df = pd.DataFrame(data)
            else:
                # 如果是普通列表，转换为单列
                df = pd.DataFrame(data, columns=["值"])
        else:
            # 如果是单个值，创建单行单列
            df = pd.DataFrame([[data]], columns=["值"])
        
        return df
    
    def save_result(self):
        """保存转换结果"""
        if self.current_data is None:
            messagebox.showwarning("警告", "请先转换JSON数据")
            return
        
        output_format = self.output_format_var.get()
        
        if output_format == "Excel":
            file_types = [("Excel Files", "*.xlsx"), ("All Files", "*.*")]
            default_ext = ".xlsx"
        elif output_format == "CSV":
            file_types = [("CSV Files", "*.csv"), ("All Files", "*.*")]
            default_ext = ".csv"
        else:
            file_types = [("JSON Files", "*.json"), ("All Files", "*.*")]
            default_ext = ".json"
        
        file_path = filedialog.asksaveasfilename(
            title="保存转换结果",
            defaultextension=default_ext,
            filetypes=file_types
        )
        
        if file_path:
            try:
                self.status_bar.set_status("正在保存...", show_progress=True)
                
                # 重新处理数据（使用保存时的当前选项）
                if self.flatten_var.get():
                    processed_data = self.flatten_json(self.current_data)
                else:
                    processed_data = self.current_data
                
                if output_format == "Excel":
                    df = self.convert_to_excel(processed_data)
                    df.to_excel(file_path, index=False)
                    self.status_bar.update_progress(100)
                elif output_format == "CSV":
                    df = self.convert_to_excel(processed_data)
                    df.to_csv(file_path, index=False, encoding="utf-8-sig")
                    self.status_bar.update_progress(100)
                else:  # JSON
                    result = json.dumps(processed_data, ensure_ascii=False, indent=2)
                    with open(file_path, "w", encoding="utf-8") as f:
                        f.write(result)
                    self.status_bar.update_progress(100)
                
                messagebox.showinfo("成功", f"文件已保存到: {file_path}")
                self.status_bar.set_status(f"已保存: {file_path}")
                
            except Exception as e:
                messagebox.showerror("错误", f"保存失败: {str(e)}")
                self.status_bar.set_status("保存失败")
    
    def on_tab_focus(self):
        """标签页获得焦点时调用"""
        self.status_bar.set_status("JSON转换模块已激活")
    
    def cleanup(self):
        """清理资源"""
        self.current_file = None
        self.current_data = None
