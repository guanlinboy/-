﻿# -*- coding: utf-8 -*-
"""
文件分类模块
"""

import tkinter as tk
from tkinter import ttk, filedialog, messagebox, scrolledtext
import os
import shutil
from datetime import datetime
from utils.file_utils import FileUtils

class FileClassifierModule:
    """文件分类功能模块"""
    
    def __init__(self, notebook, status_bar):
        self.notebook = notebook
        self.status_bar = status_bar
        
        # 创建标签页
        self.tab_frame = ttk.Frame(notebook)
        notebook.add(self.tab_frame, text="文件分类")
        
        # 默认分类规则
        self.classification_rules = {
            '文档': ['.txt', '.doc', '.docx', '.pdf', '.rtf'],
            '图片': ['.jpg', '.jpeg', '.png', '.gif', '.bmp', '.tiff'],
            '音频': ['.mp3', '.wav', '.flac', '.aac', '.m4a'],
            '视频': ['.mp4', '.avi', '.mkv', '.mov', '.wmv', '.flv'],
            '压缩文件': ['.zip', '.rar', '.7z', '.tar', '.gz'],
            '代码': ['.py', '.js', '.html', '.css', '.java', '.cpp', '.c'],
            '表格': ['.xlsx', '.xls', '.csv'],
            '演示文稿': ['.pptx', '.ppt'],
            '其他': []
        }
        
        self.setup_ui()
        self.source_directory = None
        self.classification_results = None
    
    def setup_ui(self):
        """设置用户界面"""
        # 主容器
        main_frame = ttk.Frame(self.tab_frame, padding="10")
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        # 左侧：源文件夹和规则设置
        left_frame = ttk.Frame(main_frame)
        left_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 5))
        
        # 源文件夹选择
        source_frame = ttk.LabelFrame(left_frame, text="源文件夹", padding="5")
        source_frame.pack(fill=tk.X, pady=(0, 10))
        
        self.source_var = tk.StringVar()
        source_entry = ttk.Entry(source_frame, textvariable=self.source_var, width=40)
        source_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 5))
        
        ttk.Button(source_frame, text="浏览", command=self.browse_source_folder).pack(side=tk.RIGHT)
        
        # 分类规则设置
        rules_frame = ttk.LabelFrame(left_frame, text="分类规则", padding="5")
        rules_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 10))
        
        # 创建规则列表
        self.rules_tree = ttk.Treeview(rules_frame, columns=('扩展名',), show="tree headings", height=8)
        self.rules_tree.heading('#0', text='分类名称')
        self.rules_tree.heading('扩展名', text='文件扩展名')
        self.rules_tree.column('#0', width=100)
        self.rules_tree.column('扩展名', width=200)
        
        # 规则滚动条
        rules_scrollbar = ttk.Scrollbar(rules_frame, orient=tk.VERTICAL, command=self.rules_tree.yview)
        self.rules_tree.configure(yscrollcommand=rules_scrollbar.set)
        
        self.rules_tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        rules_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # 规则编辑按钮
        rules_button_frame = ttk.Frame(left_frame)
        rules_button_frame.pack(fill=tk.X, pady=(0, 10))
        
        ttk.Button(rules_button_frame, text="添加分类", command=self.add_category).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Button(rules_button_frame, text="编辑分类", command=self.edit_category).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Button(rules_button_frame, text="删除分类", command=self.delete_category).pack(side=tk.LEFT)
        
        # 操作按钮
        action_frame = ttk.Frame(left_frame)
        action_frame.pack(fill=tk.X)
        
        ttk.Button(action_frame, text="扫描文件", command=self.scan_files).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Button(action_frame, text="执行分类", command=self.execute_classification).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Button(action_frame, text="导出报告", command=self.export_report).pack(side=tk.LEFT)
        
        # 右侧：预览和日志
        right_frame = ttk.Frame(main_frame)
        right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)
        
        # 预览区域
        preview_frame = ttk.LabelFrame(right_frame, text="分类预览", padding="5")
        preview_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 10))
        
        # 预览列表
        self.preview_tree = ttk.Treeview(preview_frame, columns=('路径', '目标分类', '状态'), show="headings", height=10)
        self.preview_tree.heading('路径', text='文件路径')
        self.preview_tree.heading('目标分类', text='目标分类')
        self.preview_tree.heading('状态', text='状态')
        self.preview_tree.column('路径', width=200)
        self.preview_tree.column('目标分类', width=100)
        self.preview_tree.column('状态', width=80)
        
        # 预览滚动条
        preview_scrollbar = ttk.Scrollbar(preview_frame, orient=tk.VERTICAL, command=self.preview_tree.yview)
        self.preview_tree.configure(yscrollcommand=preview_scrollbar.set)
        
        self.preview_tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        preview_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # 日志区域
        log_frame = ttk.LabelFrame(right_frame, text="操作日志", padding="5")
        log_frame.pack(fill=tk.BOTH, expand=True)
        
        self.log_text = scrolledtext.ScrolledText(log_frame, height=8, wrap=tk.WORD)
        self.log_text.pack(fill=tk.BOTH, expand=True)
        
        # 初始化规则显示
        self.refresh_rules_display()
    
    def browse_source_folder(self):
        """浏览选择源文件夹"""
        folder_path = filedialog.askdirectory(title="选择要分类的文件夹")
        
        if folder_path:
            self.source_var.set(folder_path)
            self.source_directory = folder_path
            self.status_bar.set_status(f"已选择文件夹: {folder_path}")
            self.add_log(f"选择源文件夹: {folder_path}")
    
    def refresh_rules_display(self):
        """刷新规则显示"""
        # 清除现有项
        for item in self.rules_tree.get_children():
            self.rules_tree.delete(item)
        
        # 添加规则
        for category, extensions in self.classification_rules.items():
            extensions_str = ', '.join(extensions) if extensions else '未分类文件'
            self.rules_tree.insert('', tk.END, text=category, values=(extensions_str,))
    
    def add_category(self):
        """添加分类"""
        dialog = CategoryDialog(self.tab_frame, "添加分类")
        self.tab_frame.wait_window(dialog.top)
        
        if dialog.result:
            category, extensions = dialog.result
            self.classification_rules[category] = extensions
            self.refresh_rules_display()
            self.add_log(f"添加分类: {category}")
    
    def edit_category(self):
        """编辑分类"""
        selected = self.rules_tree.selection()
        if not selected:
            messagebox.showwarning("警告", "请选择要编辑的分类")
            return
        
        item = selected[0]
        category = self.rules_tree.item(item)['text']
        current_extensions = self.classification_rules.get(category, [])
        
        dialog = CategoryDialog(self.tab_frame, "编辑分类", category, current_extensions)
        self.tab_frame.wait_window(dialog.top)
        
        if dialog.result:
            new_category, extensions = dialog.result
            del self.classification_rules[category]
            self.classification_rules[new_category] = extensions
            self.refresh_rules_display()
            self.add_log(f"编辑分类: {category} -> {new_category}")
    
    def delete_category(self):
        """删除分类"""
        selected = self.rules_tree.selection()
        if not selected:
            messagebox.showwarning("警告", "请选择要删除的分类")
            return
        
        item = selected[0]
        category = self.rules_tree.item(item)['text']
        
        if messagebox.askyesno("确认删除", f"确定要删除分类 '{category}' 吗？"):
            del self.classification_rules[category]
            self.refresh_rules_display()
            self.add_log(f"删除分类: {category}")
    
    def scan_files(self):
        """扫描文件"""
        if not self.source_directory:
            messagebox.showwarning("警告", "请先选择源文件夹")
            return
        
        try:
            self.status_bar.set_status("正在扫描文件...", show_progress=True)
            self.status_bar.update_progress(25)
            
            # 清除现有预览
            for item in self.preview_tree.get_children():
                self.preview_tree.delete(item)
            
            self.classification_results = []
            file_count = 0
            
            # 扫描文件
            for root, dirs, files in os.walk(self.source_directory):
                for filename in files:
                    file_path = os.path.join(root, filename)
                    extension = FileUtils.get_file_extension(filename)
                    
                    # 确定分类
                    target_category = self.classify_file(extension)
                    
                    result = {
                        'path': file_path,
                        'filename': filename,
                        'extension': extension,
                        'category': target_category,
                        'status': '待处理'
                    }
                    
                    self.classification_results.append(result)
                    
                    # 添加到预览
                    relative_path = os.path.relpath(file_path, self.source_directory)
                    self.preview_tree.insert('', tk.END, values=(
                        relative_path,
                        target_category,
                        '待处理'
                    ))
                    
                    file_count += 1
                    
                    if file_count % 100 == 0:
                        self.status_bar.update_progress(min(75, 25 + (file_count / 10)))
            
            self.status_bar.update_progress(100)
            self.status_bar.set_status(f"扫描完成，共找到 {file_count} 个文件")
            self.add_log(f"扫描完成，共找到 {file_count} 个文件")
            
        except Exception as e:
            messagebox.showerror("错误", f"扫描失败: {str(e)}")
            self.status_bar.set_status("扫描失败")
    
    def classify_file(self, extension):
        """根据扩展名分类文件"""
        for category, extensions in self.classification_rules.items():
            if extension.lower() in extensions:
                return category
        return '其他'
    
    def execute_classification(self):
        """执行分类"""
        if not self.classification_results:
            messagebox.showwarning("警告", "请先扫描文件")
            return
        
        if not messagebox.askyesno("确认执行", "确定要执行文件分类吗？此操作将移动文件到相应目录。"):
            return
        
        try:
            self.status_bar.set_status("正在执行分类...", show_progress=True)
            processed_count = 0
            total_count = len(self.classification_results)
            
            for i, result in enumerate(self.classification_results):
                if result['status'] == '已完成':
                    continue
                
                try:
                    # 创建目标目录
                    target_dir = os.path.join(self.source_directory, result['category'])
                    FileUtils.ensure_directory(target_dir)
                    
                    # 移动文件
                    target_path = os.path.join(target_dir, result['filename'])
                    success, msg = FileUtils.move_file(result['path'], target_path)
                    
                    if success:
                        result['status'] = '已完成'
                        self.add_log(f"移动文件: {result['filename']} -> {result['category']}")
                    else:
                        result['status'] = '失败'
                        self.add_log(f"移动失败: {result['filename']} - {msg}")
                    
                except Exception as e:
                    result['status'] = '失败'
                    self.add_log(f"处理文件失败: {result['filename']} - {str(e)}")
                
                processed_count += 1
                progress = int((processed_count / total_count) * 100)
                self.status_bar.update_progress(progress)
                
                # 更新预览
                self.update_preview_item(result)
            
            self.status_bar.set_status(f"分类完成，处理了 {processed_count} 个文件")
            self.add_log(f"分类执行完成，处理了 {processed_count} 个文件")
            
        except Exception as e:
            messagebox.showerror("错误", f"分类执行失败: {str(e)}")
            self.status_bar.set_status("分类失败")
    
    def update_preview_item(self, result):
        """更新预览项"""
        for item in self.preview_tree.get_children():
            values = self.preview_tree.item(item)['values']
            if values[0] == os.path.relpath(result['path'], self.source_directory):
                self.preview_tree.item(item, values=(values[0], values[1], result['status']))
                break
    
    def export_report(self):
        """导出报告"""
        if not self.classification_results:
            messagebox.showwarning("警告", "没有数据可导出")
            return
        
        file_path = filedialog.asksaveasfilename(
            title="导出分类报告",
            defaultextension=".txt",
            filetypes=[("Text Files", "*.txt"), ("All Files", "*.*")]
        )
        
        if file_path:
            try:
                with open(file_path, 'w', encoding='utf-8') as f:
                    f.write("文件分类报告\n")
                    f.write("=" * 50 + "\n")
                    f.write(f"生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
                    f.write(f"源文件夹: {self.source_directory}\n\n")
                    
                    # 统计各分类的文件数量
                    category_stats = {}
                    for result in self.classification_results:
                        category = result['category']
                        if category not in category_stats:
                            category_stats[category] = {'total': 0, 'completed': 0}
                        category_stats[category]['total'] += 1
                        if result['status'] == '已完成':
                            category_stats[category]['completed'] += 1
                    
                    f.write("分类统计:\n")
                    for category, stats in category_stats.items():
                        f.write(f"  {category}: {stats['completed']}/{stats['total']}\n")
                    
                    f.write("\n详细列表:\n")
                    f.write("-" * 50 + "\n")
                    
                    for result in self.classification_results:
                        relative_path = os.path.relpath(result['path'], self.source_directory)
                        f.write(f"{relative_path} -> {result['category']} [{result['status']}]\n")
                
                messagebox.showinfo("成功", f"报告已导出到: {file_path}")
                self.status_bar.set_status(f"报告已导出: {file_path}")
                
            except Exception as e:
                messagebox.showerror("错误", f"导出报告失败: {str(e)}")
    
    def add_log(self, message):
        """添加日志"""
        timestamp = datetime.now().strftime('%H:%M:%S')
        log_entry = f"[{timestamp}] {message}\n"
        self.log_text.insert(tk.END, log_entry)
        self.log_text.see(tk.END)
    
    def on_tab_focus(self):
        """标签页获得焦点时调用"""
        self.status_bar.set_status("文件分类模块已激活")
    
    def cleanup(self):
        """清理资源"""
        self.classification_results = None
        self.source_directory = None

class CategoryDialog:
    """分类编辑对话框"""
    
    def __init__(self, parent, title, category='', extensions=None):
        self.result = None
        
        self.top = tk.Toplevel(parent)
        self.top.title(title)
        self.top.geometry("400x200")
        self.top.resizable(False, False)
        self.top.transient(parent)
        self.top.grab_set()
        
        # 分类名称
        ttk.Label(self.top, text="分类名称:").pack(pady=5)
        self.category_var = tk.StringVar(value=category)
        ttk.Entry(self.top, textvariable=self.category_var, width=40).pack(pady=5)
        
        # 文件扩展名
        ttk.Label(self.top, text="文件扩展名 (用逗号分隔):").pack(pady=5)
        extensions_str = ', '.join(extensions) if extensions else ''
        self.extensions_var = tk.StringVar(value=extensions_str)
        ttk.Entry(self.top, textvariable=self.extensions_var, width=40).pack(pady=5)
        
        # 按钮
        button_frame = ttk.Frame(self.top)
        button_frame.pack(pady=20)
        
        ttk.Button(button_frame, text="确定", command=self.ok_clicked).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="取消", command=self.cancel_clicked).pack(side=tk.LEFT, padx=5)
        
        # 居中显示
        self.top.update_idletasks()
        x = (self.top.winfo_screenwidth() // 2) - (self.top.winfo_width() // 2)
        y = (self.top.winfo_screenheight() // 2) - (self.top.winfo_height() // 2)
        self.top.geometry(f"+{x}+{y}")
    
    def ok_clicked(self):
        """确定按钮点击"""
        category = self.category_var.get().strip()
        extensions_str = self.extensions_var.get().strip()
        
        if not category:
            messagebox.showwarning("警告", "请输入分类名称")
            return
        
        # 解析扩展名
        extensions = [ext.strip() for ext in extensions_str.split(',') if ext.strip()]
        
        self.result = (category, extensions)
        self.top.destroy()
    
    def cancel_clicked(self):
        """取消按钮点击"""
        self.top.destroy()
