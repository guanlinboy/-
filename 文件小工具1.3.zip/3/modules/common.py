﻿# -*- coding: utf-8 -*-
"""
通用模块 - 共享组件和工具类
"""

import tkinter as tk
from tkinter import ttk
import threading
import time

class StatusBar:
    """状态栏组件"""
    
    def __init__(self, parent):
        self.parent = parent
        self.status_var = tk.StringVar()
        self.progress_var = tk.DoubleVar()
        
        # 创建状态栏框架
        self.frame = ttk.Frame(parent, relief=tk.SUNKEN, borderwidth=1)
        
        # 状态标签
        self.status_label = ttk.Label(self.frame, textvariable=self.status_var, relief=tk.SUNKEN)
        self.status_label.pack(side=tk.LEFT, fill=tk.X, expand=True)
        
        # 进度条（初始隐藏）
        self.progress_bar = ttk.Progressbar(self.frame, variable=self.progress_var, 
                                           mode="determinate", length=200)
        
        # 初始化状态
        self.set_status("就绪")
    
    def set_status(self, text, show_progress=False):
        """设置状态文本"""
        self.status_var.set(text)
        
        if show_progress:
            self.progress_bar.pack(side=tk.RIGHT, padx=5, pady=2)
        else:
            self.progress_bar.pack_forget()
            self.progress_var.set(0)
    
    def update_progress(self, value):
        """更新进度"""
        self.progress_var.set(value)
        self.status_label.update()
    
    def pack(self, **kwargs):
        """包装方法"""
        self.frame.pack(**kwargs)

class StyleManager:
    """样式管理器"""
    
    def __init__(self):
        self.theme = "light"
        self.style_path = "themes/default.tcl"
    
    def get_style(self):
        """获取样式文件路径"""
        return self.style_path
    
    def set_theme(self, theme):
        """设置主题"""
        self.theme = theme

class ConfigManager:
    """配置管理器单例"""
    
    _instance = None
    _config = {}
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance
    
    def get(self, key, default=None):
        """获取配置值"""
        keys = key.split(".")
        value = self._config
        
        for k in keys:
            if isinstance(value, dict) and k in value:
                value = value[k]
            else:
                return default
        
        return value
    
    def set(self, key, value):
        """设置配置值"""
        keys = key.split(".")
        config = self._config
        
        for k in keys[:-1]:
            if k not in config:
                config[k] = {}
            config = config[k]
        
        config[keys[-1]] = value
    
    def load_config(self, config_data):
        """加载配置"""
        self._config.update(config_data)
    
    def save_config(self, config_data):
        """保存配置"""
        self._config.clear()
        self._config.update(config_data)
    
    @property
    def config(self):
        return self._config.copy()

class ThreadSafeCounter:
    """线程安全的计数器"""
    
    def __init__(self, initial_value=0):
        self._value = initial_value
        self._lock = threading.Lock()
    
    def increment(self, delta=1):
        """递增"""
        with self._lock:
            self._value += delta
            return self._value
    
    def get_value(self):
        """获取当前值"""
        with self._lock:
            return self._value
    
    def reset(self, value=0):
        """重置"""
        with self._lock:
            self._value = value

class WorkerThread(threading.Thread):
    """工作线程基类"""
    
    def __init__(self, callback=None):
        super().__init__()
        self.callback = callback
        self._stop_event = threading.Event()
        self._result = None
        self._error = None
    
    def run(self):
        """线程运行方法，子类需要重写"""
        try:
            self._result = self.work()
            if self.callback:
                self.callback(True, self._result, None)
        except Exception as e:
            self._error = e
            if self.callback:
                self.callback(False, None, str(e))
    
    def work(self):
        """工作方法，子类需要重写"""
        raise NotImplementedError("Subclasses must implement work method")
    
    def stop(self):
        """停止线程"""
        self._stop_event.set()
    
    def is_stopped(self):
        """检查是否已停止"""
        return self._stop_event.is_set()

class Debouncer:
    """防抖器"""
    
    def __init__(self, delay=0.3):
        self.delay = delay
        self.timer = None
        self.callback = None
    
    def debounce(self, callback):
        """设置回调函数"""
        self.callback = callback
    
    def __call__(self, *args, **kwargs):
        """调用防抖器"""
        if self.timer:
            self.timer.cancel()
        
        self.timer = threading.Timer(self.delay, self._execute, args, kwargs)
        self.timer.start()
    
    def _execute(self, *args, **kwargs):
        """执行回调"""
        if self.callback:
            self.callback(*args, **kwargs)

# 全局实例
style_manager = StyleManager()
