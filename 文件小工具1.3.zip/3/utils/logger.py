﻿# -*- coding: utf-8 -*-
"""
日志工具 - 应用日志管理
"""

import logging
import os
from datetime import datetime

class Logger:
    """日志管理器"""
    
    def __init__(self, log_file=None):
        self.logger = logging.getLogger('FileToolbox')
        self.logger.setLevel(logging.DEBUG)
        
        # 清除现有处理器
        self.logger.handlers.clear()
        
        # 创建格式化器
        formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        )
        
        # 控制台处理器
        console_handler = logging.StreamHandler()
        console_handler.setLevel(logging.INFO)
        console_handler.setFormatter(formatter)
        self.logger.addHandler(console_handler)
        
        # 文件处理器
        if log_file is None:
            log_dir = "logs"
            if not os.path.exists(log_dir):
                os.makedirs(log_dir)
            
            log_filename = f"toolbox_{datetime.now().strftime('%Y-%m-%d')}.log"
            log_file = os.path.join(log_dir, log_filename)
        
        file_handler = logging.FileHandler(log_file, encoding='utf-8')
        file_handler.setLevel(logging.DEBUG)
        file_handler.setFormatter(formatter)
        self.logger.addHandler(file_handler)
    
    def debug(self, message):
        """调试日志"""
        self.logger.debug(message)
    
    def info(self, message):
        """信息日志"""
        self.logger.info(message)
    
    def warning(self, message):
        """警告日志"""
        self.logger.warning(message)
    
    def error(self, message):
        """错误日志"""
        self.logger.error(message)
    
    def success(self, message):
        """成功日志"""
        self.logger.info(f"✅ {message}")
    
    def critical(self, message):
        """严重错误日志"""
        self.logger.critical(message)

# 全局日志实例
logger = Logger()
