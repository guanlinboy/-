﻿# -*- coding: utf-8 -*-
"""
配置加载器 - 应用配置管理
"""

import json
import os
from modules.common import ConfigManager

config_manager = ConfigManager()

class ConfigLoader:
    """配置加载器类"""
    
    def __init__(self, config_file="settings.json"):
        self.config_file = config_file
        self.load_default_config()
        self.load_config_file()
    
    def load_default_config(self):
        """加载默认配置"""
        default_config = {
            "ui": {
                "window_width": 1200,
                "window_height": 800,
                "font_size": 10,
                "theme": {
                    "mode": "light"
                }
            },
            "excel_search": {
                "default_threshold": 70,
                "max_results": 1000,
                "highlight_matches": True
            },
            "json_converter": {
                "flatten_json": True,
                "auto_detect_types": True,
                "max_file_size_mb": 50
            },
            "file_classifier": {
                "confirm_before_move": True,
                "create_backup": True,
                "supported_extensions": [".txt", ".doc", ".docx", ".pdf", ".jpg", ".png", ".xlsx", ".csv"]
            },
            "paths": {
                "backup_directory": "",
                "last_opened_directory": ""
            }
        }
        
        config_manager.load_config(default_config)
    
    def load_config_file(self):
        """从文件加载配置"""
        try:
            if os.path.exists(self.config_file):
                with open(self.config_file, "r", encoding="utf-8-sig") as f:
                    file_config = json.load(f)
                
                self._deep_update(config_manager._config, file_config)
                
        except Exception as e:
            print(f"加载配置文件失败: {e}")
    
    def save_config_file(self):
        """保存配置到文件"""
        try:
            with open(self.config_file, "w", encoding="utf-8") as f:
                json.dump(config_manager.config, f, ensure_ascii=False, indent=2)
            return True, "配置保存成功"
        except Exception as e:
            return False, f"配置保存失败: {e}"
    
    def _deep_update(self, target_dict, source_dict):
        """深度更新字典"""
        for key, value in source_dict.items():
            if key in target_dict and isinstance(target_dict[key], dict) and isinstance(value, dict):
                self._deep_update(target_dict[key], value)
            else:
                target_dict[key] = value

_config_loader = ConfigLoader()
