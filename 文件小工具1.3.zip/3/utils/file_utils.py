﻿# -*- coding: utf-8 -*-
"""
文件工具 - 文件操作工具类
"""

import os
import json
import shutil
from datetime import datetime
import re

class FileUtils:
    """文件操作工具类"""
    
    @staticmethod
    def ensure_directory(directory):
        """确保目录存在"""
        if not os.path.exists(directory):
            os.makedirs(directory)
        return directory
    
    @staticmethod
    def get_file_extension(filename):
        """获取文件扩展名"""
        return os.path.splitext(filename)[1].lower()
    
    @staticmethod
    def detect_encoding(file_path):
        """检测文件编码"""
        try:
            with open(file_path, "rb") as f:
                raw_data = f.read(1000)
            
            encodings = ["utf-8", "gbk", "gb2312", "latin-1"]
            for encoding in encodings:
                try:
                    raw_data.decode(encoding)
                    return encoding
                except:
                    continue
            return "utf-8"
        except:
            return "utf-8"
    
    @staticmethod
    def load_json(file_path, encoding="utf-8"):
        """加载JSON文件"""
        try:
            with open(file_path, "r", encoding=encoding) as f:
                data = json.load(f)
            return True, data, "加载成功"
        except Exception as e:
            return False, None, f"加载JSON失败: {str(e)}"
    
    @staticmethod
    def save_json(data, file_path, encoding="utf-8", indent=2):
        """保存JSON文件"""
        try:
            FileUtils.ensure_directory(os.path.dirname(file_path))
            
            with open(file_path, "w", encoding=encoding) as f:
                json.dump(data, f, ensure_ascii=False, indent=indent)
            return True, "保存成功"
        except Exception as e:
            return False, f"保存JSON失败: {str(e)}"
    
    @staticmethod
    def backup_file(file_path, backup_dir=None):
        """备份文件"""
        try:
            if not os.path.exists(file_path):
                return False, "源文件不存在"
            
            if backup_dir is None:
                backup_dir = os.path.join(os.path.dirname(file_path), "backup")
            
            FileUtils.ensure_directory(backup_dir)
            
            filename = os.path.basename(file_path)
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            backup_name = f"{timestamp}_{filename}"
            backup_path = os.path.join(backup_dir, backup_name)
            
            shutil.copy2(file_path, backup_path)
            return True, backup_path
        except Exception as e:
            return False, f"备份失败: {str(e)}"
    
    @staticmethod
    def move_file(src, dst, create_backup=True):
        """移动文件"""
        try:
            if not os.path.exists(src):
                return False, "源文件不存在"
            
            if os.path.exists(dst) and create_backup:
                FileUtils.backup_file(dst)
            
            FileUtils.ensure_directory(os.path.dirname(dst))
            
            shutil.move(src, dst)
            return True, "移动成功"
        except Exception as e:
            return False, f"移动失败: {str(e)}"
    
    @staticmethod
    def copy_file(src, dst):
        """复制文件"""
        try:
            if not os.path.exists(src):
                return False, "源文件不存在"
            
            FileUtils.ensure_directory(os.path.dirname(dst))
            shutil.copy2(src, dst)
            return True, "复制成功"
        except Exception as e:
            return False, f"复制失败: {str(e)}"
    
    @staticmethod
    def delete_file(file_path, create_backup=True):
        """删除文件"""
        try:
            if not os.path.exists(file_path):
                return False, "文件不存在"
            
            if create_backup:
                FileUtils.backup_file(file_path)
            
            os.remove(file_path)
            return True, "删除成功"
        except Exception as e:
            return False, f"删除失败: {str(e)}"
    
    @staticmethod
    def get_file_size(file_path):
        """获取文件大小（字节）"""
        try:
            return os.path.getsize(file_path)
        except:
            return 0
    
    @staticmethod
    def format_file_size(size_bytes):
        """格式化文件大小"""
        if size_bytes == 0:
            return "0 B"
        
        size_names = ["B", "KB", "MB", "GB", "TB"]
        import math
        i = int(math.floor(math.log(size_bytes, 1024)))
        p = math.pow(1024, i)
        s = round(size_bytes / p, 2)
        return f"{s} {size_names[i]}"
    
    @staticmethod
    def is_text_file(file_path):
        """判断是否为文本文件"""
        text_extensions = {
            ".txt", ".py", ".js", ".html", ".css", ".xml", ".json", 
            ".md", ".log", ".ini", ".cfg", ".conf", ".yml", ".yaml"
        }
        
        extension = FileUtils.get_file_extension(file_path)
        return extension in text_extensions
    
    @staticmethod
    def get_files_by_extension(directory, extensions):
        """根据扩展名获取文件列表"""
        files = []
        if isinstance(extensions, str):
            extensions = [extensions]
        
        extensions = set(ext.lower() for ext in extensions)
        
        for root, dirs, filenames in os.walk(directory):
            for filename in filenames:
                if FileUtils.get_file_extension(filename) in extensions:
                    files.append(os.path.join(root, filename))
        
        return files
    
    @staticmethod
    def clean_filename(filename):
        """清理文件名，移除非法字符"""
        illegal_chars = r"[<>:\"/\\\\|?*]"
        cleaned = re.sub(illegal_chars, "_", filename)
        return cleaned.strip()
