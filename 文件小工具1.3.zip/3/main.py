﻿# -*- coding: utf-8 -*-
"""
FileToolbox - 文件处理工具箱

一个集成的文件处理工具，包含Excel模糊搜索、JSON转Excel转换和文件自动分类功能。
"""

import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import sys
import os
from datetime import datetime
import threading
import webbrowser

# 确保项目目录在Python路径中
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from utils.config_loader import config_manager
from utils.logger import logger
from utils.file_utils import FileUtils
from modules.common import style_manager, StatusBar
from modules.excel_search import ExcelSearchModule
from modules.json_converter import JSONConverterModule
from modules.file_classifier import FileClassifierModule

class FileToolboxApp:
    """文件处理工具箱主应用程序"""
    
    def __init__(self):
        self.root = tk.Tk()
        self.setup_window()
        self.setup_ui()
        self.setup_styles()
        self.bind_events()
        
        # 模块实例
        self.modules = {}
        
        # 状态标志
        self.is_closing = False
        
        # 初始化模块
        self._initialize_modules()
    
    def setup_window(self):
        """设置主窗口"""
        self.root.title("FileToolbox - 文件处理工具箱")
        
        # 获取配置的窗口大小
        width = config_manager.get("ui.window_width", 1200)
        height = config_manager.get("ui.window_height", 800)
        
        # 计算屏幕中心位置
        screen_width = self.root.winfo_screenwidth()
        screen_height = self.root.winfo_screenheight()
        x = (screen_width - width) // 2
        y = (screen_height - height) // 2
        
        self.root.geometry(f"{width}x{height}+{x}+{y}")
        self.root.minsize(800, 600)
        
        # 设置应用图标（如果存在）
        try:
            icon_path = os.path.join("resources", "icon.ico")
            if os.path.exists(icon_path):
                self.root.iconbitmap(icon_path)
        except Exception:
            pass
        
        # 根据主题设置背景色
        theme = config_manager.get("theme.mode", "light")
        if theme == "light":
            bg_color = "#f0f0f0"
        else:
            bg_color = "#2E2E2E"
        
        self.root.configure(bg=bg_color)
    
    def setup_ui(self):
        """设置用户界面"""
        # 主容器
        main_container = ttk.Frame(self.root)
        main_container.pack(fill=tk.BOTH, expand=True)
        
        # 创建工具栏
        self._create_toolbar(main_container)
        
        # 创建主要内容区域
        content_frame = ttk.Frame(main_container)
        content_frame.pack(fill=tk.BOTH, expand=True)
        
        # 创建标签页
        self._create_tabbed_content(content_frame)
        
        # 创建状态栏
        self._create_status_bar(main_container)
    
    def _create_toolbar(self, parent):
        """创建工具栏"""
        toolbar = ttk.Frame(parent, relief=tk.RAISED, borderwidth=1)
        toolbar.pack(fill=tk.X, padx=(0, 0), pady=(0, 2))
        
        # 应用标题
        title_label = ttk.Label(toolbar, text="FileToolbox", 
                               font=("Microsoft YaHei", 14, "bold"))
        title_label.pack(side=tk.LEFT, padx=10, pady=5)
        
        # 版本信息
        version_label = ttk.Label(toolbar, text="v1.0.0", 
                                 font=("Microsoft YaHei", 9))
        version_label.pack(side=tk.LEFT, padx=(0, 20), pady=5)
        
        # 功能按钮
        ttk.Button(toolbar, text="设置", command=self._open_settings).pack(side=tk.RIGHT, padx=5, pady=5)
        ttk.Button(toolbar, text="帮助", command=self._show_help).pack(side=tk.RIGHT, padx=5, pady=5)
        ttk.Button(toolbar, text="关于", command=self._show_about).pack(side=tk.RIGHT, padx=5, pady=5)
        
        # 主题切换
        theme_var = tk.StringVar(value=config_manager.get("theme.mode", "light"))
        theme_frame = ttk.Frame(toolbar)
        theme_frame.pack(side=tk.RIGHT, padx=10, pady=5)
        
        ttk.Label(theme_frame, text="主题:").pack(side=tk.LEFT, padx=(0, 5))
        
        light_radio = ttk.Radiobutton(theme_frame, text="浅色", variable=theme_var, 
                                     value="light", command=lambda: self._switch_theme("light"))
        light_radio.pack(side=tk.LEFT, padx=(0, 5))
        
        dark_radio = ttk.Radiobutton(theme_frame, text="深色", variable=theme_var, 
                                    value="dark", command=lambda: self._switch_theme("dark"))
        dark_radio.pack(side=tk.LEFT)
    
    def _create_tabbed_content(self, parent):
        """创建标签页内容"""
        # 创建Notebook控件用于标签页
        self.notebook = ttk.Notebook(parent)
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # 绑定标签页切换事件
        self.notebook.bind("<<NotebookTabChanged>>", self._on_tab_changed)
    
    def _create_status_bar(self, parent):
        """创建状态栏"""
        self.status_bar = StatusBar(parent)
        self.status_bar.pack(side=tk.BOTTOM, fill=tk.X)
        
        # 设置初始状态
        self.status_bar.set_status("就绪")
    
    def _initialize_modules(self):
        """初始化所有功能模块"""
        try:
            # Excel搜索模块
            excel_module = ExcelSearchModule(self.notebook, self.status_bar)
            self.modules["excel"] = excel_module
            
            # JSON转换模块
            json_module = JSONConverterModule(self.notebook, self.status_bar)
            self.modules["json"] = json_module
            
            # 文件分类模块
            classifier_module = FileClassifierModule(self.notebook, self.status_bar)
            self.modules["classifier"] = classifier_module
            
            logger.info("所有模块初始化完成")
            self.status_bar.set_status("所有模块已加载")
            
        except Exception as e:
            logger.error(f"模块初始化失败: {str(e)}")
            messagebox.showerror("错误", f"模块初始化失败: {str(e)}")
    
    def setup_styles(self):
        """设置界面样式"""
        try:
            style = style_manager.get_style()
            self.root.tk.call("source", style)
        except Exception:
            # 如果样式文件不存在，使用默认样式
            pass
    
    def bind_events(self):
        """绑定事件处理"""
        # 窗口关闭事件
        self.root.protocol("WM_DELETE_WINDOW", self._on_closing)
        
        # 快捷键绑定
        self.root.bind("<Control-s>", lambda e: self._save_settings())
        self.root.bind("<Control-q>", lambda e: self._on_closing())
        self.root.bind("<F1>", lambda e: self._show_help())
    
    def _on_tab_changed(self, event):
        """标签页切换事件处理"""
        try:
            current_tab = self.notebook.select()
            tab_text = self.notebook.tab(current_tab, "text")
            
            # 更新状态栏
            self.status_bar.set_status(f"当前页面: {tab_text}")
            
            # 通知相应模块
            if "Excel" in tab_text and "excel" in self.modules:
                self.modules["excel"].on_tab_focus()
            elif "JSON" in tab_text and "json" in self.modules:
                self.modules["json"].on_tab_focus()
            elif "分类" in tab_text and "classifier" in self.modules:
                self.modules["classifier"].on_tab_focus()
                
        except Exception as e:
            logger.error(f"标签页切换错误: {str(e)}")
    
    def _switch_theme(self, theme):
        """切换主题"""
        try:
            config_manager.set("theme.mode", theme)
            
            # 重新启动应用以应用主题
            if messagebox.askyesno("主题切换", "主题切换需要重启应用，是否继续？"):
                self._restart_app()
                
        except Exception as e:
            logger.error(f"主题切换失败: {str(e)}")
            messagebox.showerror("错误", f"主题切换失败: {str(e)}")
    
    def _restart_app(self):
        """重启应用"""
        try:
            # 保存当前配置
            self._save_settings()
            
            # 重启应用
            python = sys.executable
            os.execl(python, python, *sys.argv)
            
        except Exception as e:
            logger.error(f"应用重启失败: {str(e)}")
            messagebox.showerror("错误", f"应用重启失败: {str(e)}")
    
    def _open_settings(self):
        """打开设置对话框"""
        messagebox.showinfo("设置", "设置功能正在开发中...")
    
    def _show_help(self):
        """显示帮助信息"""
        help_text = """FileToolbox 使用帮助

=== Excel搜索工具 ===
1. 点击"Excel搜索"标签页
2. 选择要搜索的Excel文件
3. 输入搜索关键词
4. 调整匹配阈值
5. 点击搜索按钮
6. 查看并导出结果

=== JSON转换工具 ===
1. 点击"JSON转换"标签页
2. 选择输入文件或粘贴数据
3. 配置转换选项
4. 选择输出格式
5. 点击转换按钮
6. 保存结果文件

=== 文件分类工具 ===
1. 点击"文件分类"标签页
2. 选择要分类的文件夹
3. 配置分类规则
4. 预览分类结果
5. 确认执行分类
6. 查看操作日志

=== 快捷键 ===
F1 - 帮助
Ctrl+S - 保存设置
Ctrl+Q - 退出应用

更多详细信息请查阅用户手册。"""
        
        messagebox.showinfo("帮助", help_text)
    
    def _show_about(self):
        """显示关于信息"""
        about_text = """FileToolbox v1.0.0

一款集成化的文件处理工具箱

主要功能：
• Excel智能搜索
• JSON/Excel转换  
• 文件智能分类
• 批量文件操作
• 自定义工具扩展

系统要求：Python 3.8+
界面框架：tkinter

© 2024 FileToolbox Project"""
        
        messagebox.showinfo("关于 FileToolbox", about_text)
    
    def _save_settings(self):
        """保存设置"""
        try:
            # TODO: 实现设置保存
            logger.info("设置已保存")
            self.status_bar.set_status("设置已保存")
            
        except Exception as e:
            logger.error(f"保存设置失败: {str(e)}")
            messagebox.showerror("错误", f"保存设置失败: {str(e)}")
    
    def _on_closing(self):
        """窗口关闭事件处理"""
        if not self.is_closing:
            self.is_closing = True
            try:
                # 保存设置
                self._save_settings()
                
                # 记录日志
                logger.info("FileToolbox 正在关闭...")
                
                # 关闭所有模块
                for module in self.modules.values():
                    if hasattr(module, "cleanup"):
                        module.cleanup()
                
                # 关闭应用
                self.root.destroy()
                
            except Exception as e:
                logger.error(f"应用关闭时发生错误: {str(e)}")
                self.root.destroy()
    
    def run(self):
        """运行应用程序"""
        try:
            # 记录启动日志
            logger.info("FileToolbox 正在启动...")
            
            # 运行主循环
            self.root.mainloop()
            
        except Exception as e:
            logger.error(f"应用程序运行异常: {str(e)}")
            messagebox.showerror("错误", f"应用程序运行异常: {str(e)}")

def main():
    """主函数"""
    try:
        # 检查Python版本
        if sys.version_info < (3, 8):
            messagebox.showerror("错误", "需要Python 3.8或更高版本")
            return
        
        # 创建并运行应用
        app = FileToolboxApp()
        app.run()
        
    except Exception as e:
        messagebox.showerror("启动错误", f"应用启动失败: {str(e)}")

if __name__ == "__main__":
    main()
